package com.hrakaroo.glob;

class EmptyOnlyEngine implements MatchingEngine {
  static final EmptyOnlyEngine EMPTY_ONLY_ENGINE = new EmptyOnlyEngine();
  
  public boolean matches(String string) {
    return (string != null && string.isEmpty());
  }
  
  public int matchingSizeInBytes() {
    return 0;
  }
  
  public int staticSizeInBytes() {
    return 0;
  }
}
