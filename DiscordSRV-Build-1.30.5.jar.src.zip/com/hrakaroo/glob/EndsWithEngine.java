package com.hrakaroo.glob;

class EndsWithEngine implements MatchingEngine {
  final char[] lowerCase;
  
  final char[] upperCase;
  
  final boolean[] matchOne;
  
  final int length;
  
  protected EndsWithEngine(char[] lowerCase, char[] upperCase, boolean[] matchOne, int length) {
    this.lowerCase = lowerCase;
    this.upperCase = upperCase;
    this.matchOne = matchOne;
    this.length = length;
  }
  
  public boolean matches(String string) {
    if (string == null)
      return false; 
    if (string.length() < this.length - 1)
      return false; 
    int charsIndex = string.length() - 1;
    for (int patternIndex = this.length - 1; patternIndex > 0; patternIndex--) {
      if (!this.matchOne[patternIndex] && string.charAt(charsIndex) != this.lowerCase[patternIndex] && string
        .charAt(charsIndex) != this.upperCase[patternIndex])
        return false; 
      charsIndex--;
    } 
    return true;
  }
  
  public int matchingSizeInBytes() {
    return 8 + staticSizeInBytes();
  }
  
  public int staticSizeInBytes() {
    return this.lowerCase.length * 5 + 4;
  }
}
