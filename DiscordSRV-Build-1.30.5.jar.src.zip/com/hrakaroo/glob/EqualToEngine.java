package com.hrakaroo.glob;

class EqualToEngine implements MatchingEngine {
  final char[] lowerCase;
  
  final char[] upperCase;
  
  final boolean[] matchOne;
  
  final int length;
  
  protected EqualToEngine(char[] lowerCase, char[] upperCase, boolean[] matchOne, int length) {
    this.lowerCase = lowerCase;
    this.upperCase = upperCase;
    this.matchOne = matchOne;
    this.length = length;
  }
  
  public boolean matches(String string) {
    if (string == null)
      return false; 
    if (this.length != string.length())
      return false; 
    int index = 0;
    while (true) {
      if (index == this.length)
        return true; 
      if (!this.matchOne[index] && string.charAt(index) != this.lowerCase[index] && string.charAt(index) != this.upperCase[index])
        return false; 
      index++;
    } 
  }
  
  public int matchingSizeInBytes() {
    return 4 + staticSizeInBytes();
  }
  
  public int staticSizeInBytes() {
    return this.lowerCase.length * 5 + 4;
  }
}
