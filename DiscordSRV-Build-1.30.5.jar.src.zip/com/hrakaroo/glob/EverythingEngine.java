package com.hrakaroo.glob;

class EverythingEngine implements MatchingEngine {
  static final EverythingEngine EVERYTHING_ENGINE = new EverythingEngine();
  
  public boolean matches(String string) {
    return (string != null);
  }
  
  public int matchingSizeInBytes() {
    return 0;
  }
  
  public int staticSizeInBytes() {
    return 0;
  }
}
