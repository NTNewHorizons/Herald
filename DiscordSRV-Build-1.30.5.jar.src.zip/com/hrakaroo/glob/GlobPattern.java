package com.hrakaroo.glob;

public class GlobPattern {
  public static final char NULL_CHARACTER = '\000';
  
  public static final int CASE_INSENSITIVE = 1;
  
  public static final int HANDLE_ESCAPES = 2;
  
  public static MatchingEngine compile(String globPattern) {
    return compile(globPattern, '*', '?', 2);
  }
  
  public static MatchingEngine compile(String globPattern, char wildcardChar, char matchOneChar, int flags) {
    char[] lowerCaseRaw, upperCaseRaw;
    boolean caseInsensitive = has(flags, 1);
    boolean handleEscapes = has(flags, 2);
    if (globPattern == null)
      throw new IllegalArgumentException("Glob Pattern can not be null"); 
    int lengthRaw = globPattern.length();
    if (caseInsensitive) {
      lowerCaseRaw = globPattern.toLowerCase().toCharArray();
      upperCaseRaw = globPattern.toUpperCase().toCharArray();
    } else {
      lowerCaseRaw = upperCaseRaw = globPattern.toCharArray();
    } 
    char[] lowerCase = new char[lengthRaw];
    char[] upperCase = new char[lengthRaw];
    boolean[] wildcard = new boolean[lengthRaw];
    boolean[] matchOne = new boolean[lengthRaw];
    for (int i = 0; i < lengthRaw; i++) {
      wildcard[i] = false;
      matchOne[i] = false;
    } 
    boolean inEscape = false;
    int wildcardCount = 0;
    int index = 0;
    for (int j = 0; j < lengthRaw; j++) {
      char lowerC = lowerCaseRaw[j];
      char upperC = upperCaseRaw[j];
      if (handleEscapes && lowerC == '\\' && !inEscape) {
        inEscape = true;
        continue;
      } 
      if (wildcardChar != '\000' && lowerC == wildcardChar) {
        if (!inEscape) {
          if (index != 0 && wildcard[index - 1])
            continue; 
          wildcard[index] = true;
          wildcardCount++;
        } 
      } else if (matchOneChar != '\000' && lowerC == matchOneChar) {
        if (!inEscape)
          matchOne[index] = true; 
      } else if (inEscape) {
        switch (lowerC) {
          case 'r':
            lowerC = upperC = '\r';
            break;
          case 'n':
            lowerC = upperC = '\n';
            break;
          case 't':
            lowerC = upperC = '\t';
            break;
          case '\\':
            lowerC = upperC = '\\';
            break;
          case 'u':
            if (j + 4 < lengthRaw) {
              String s = new String(lowerCaseRaw, j + 1, 4);
              try {
                char u = (char)Integer.parseInt(s, 16);
                upperC = Character.toUpperCase(u);
                lowerC = Character.toLowerCase(u);
              } catch (NumberFormatException e) {
                throw new RuntimeException("Bad Unicode character: " + s);
              } 
              j += 4;
              break;
            } 
            throw new RuntimeException("Bad Unicode char at end of input");
          default:
            throw new RuntimeException("Unknown escape sequence : \\" + lowerC);
        } 
      } 
      lowerCase[index] = lowerC;
      upperCase[index] = upperC;
      index++;
      inEscape = false;
      continue;
    } 
    int length = index;
    if (length == 0)
      return EmptyOnlyEngine.EMPTY_ONLY_ENGINE; 
    if (length == 1 && wildcard[0])
      return EverythingEngine.EVERYTHING_ENGINE; 
    if (wildcardCount == 0)
      return new EqualToEngine(lowerCase, upperCase, matchOne, length); 
    if (wildcardCount == 1) {
      if (wildcard[0])
        return new EndsWithEngine(lowerCase, upperCase, matchOne, length); 
      if (wildcard[length - 1])
        return new StartsWithEngine(lowerCase, upperCase, matchOne, length); 
    } 
    if (wildcardCount == 2 && wildcard[0] && wildcard[length - 1])
      return new ContainsEngine(lowerCase, upperCase, matchOne, length); 
    return new GlobEngine(lowerCase, upperCase, wildcard, matchOne, length);
  }
  
  private static boolean has(int flags, int feature) {
    return ((flags & feature) != 0);
  }
}
