package com.hrakaroo.glob;

public interface MatchingEngine {
  boolean matches(String paramString);
  
  int matchingSizeInBytes();
  
  int staticSizeInBytes();
}
