package com.hrakaroo.glob;

class StartsWithEngine implements MatchingEngine {
  final char[] lowerCase;
  
  final char[] upperCase;
  
  final boolean[] matchOne;
  
  final int length;
  
  protected StartsWithEngine(char[] lowerCase, char[] upperCase, boolean[] matchOne, int length) {
    this.lowerCase = lowerCase;
    this.upperCase = upperCase;
    this.matchOne = matchOne;
    this.length = length;
  }
  
  public boolean matches(String string) {
    if (string == null)
      return false; 
    if (string.length() < this.length - 1)
      return false; 
    for (int index = 0; index < this.length - 1; index++) {
      if (!this.matchOne[index] && string.charAt(index) != this.lowerCase[index] && string.charAt(index) != this.upperCase[index])
        return false; 
    } 
    return true;
  }
  
  public int matchingSizeInBytes() {
    return 4 + staticSizeInBytes();
  }
  
  public int staticSizeInBytes() {
    return this.lowerCase.length * 5 + 4;
  }
}
