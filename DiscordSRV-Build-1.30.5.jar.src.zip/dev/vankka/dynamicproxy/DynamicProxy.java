package dev.vankka.dynamicproxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.jetbrains.annotations.NotNull;

public class DynamicProxy {
  private final Map<String, List<Method>> methods = new HashMap<>();
  
  public DynamicProxy(@NotNull Class<?> proxyType) {
    for (Method method : proxyType.getDeclaredMethods())
      ((List<Method>)this.methods.computeIfAbsent(method.getName(), key -> new ArrayList())).add(method); 
  }
  
  @NotNull
  public Object make(@NotNull Object original, @NotNull Object proxy) {
    Class<?> originalClass = original.getClass();
    Set<Class<?>> interfaces = new LinkedHashSet<>();
    getAllInterfaces(original.getClass(), interfaces);
    return Proxy.newProxyInstance(originalClass
        .getClassLoader(), (Class[])interfaces
        .<Class<?>[]>toArray((Class<?>[][])new Class[0]), new Handler(original, proxy));
  }
  
  private void getAllInterfaces(Class<?> clazz, Set<Class<?>> interfaces) {
    while (clazz != null) {
      for (Class<?> theInterface : clazz.getInterfaces()) {
        if (interfaces.add(theInterface))
          getAllInterfaces(theInterface, interfaces); 
      } 
      clazz = clazz.getSuperclass();
    } 
  }
  
  private class Handler implements InvocationHandler {
    private final Object original;
    
    private final Object proxy;
    
    public Handler(Object original, Object proxy) {
      this.original = original;
      this.proxy = proxy;
    }
    
    public Object invoke(Object o, Method method, Object[] args) throws Throwable {
      List<Method> methodList = (List<Method>)DynamicProxy.this.methods.get(method.getName());
      if (methodList != null) {
        int parameterCount = method.getParameterCount();
        Class<?>[] parameterTypes = method.getParameterTypes();
        for (Method proxyMethod : methodList) {
          if (proxyMethod.getParameterCount() != parameterCount)
            continue; 
          if (!Arrays.equals((Object[])proxyMethod.getParameterTypes(), (Object[])parameterTypes))
            continue; 
          return invokeMethod(proxyMethod, args);
        } 
      } 
      return method.invoke(this.original, args);
    }
    
    private Object invokeMethod(Method proxyMethod, Object[] args) {
      try {
        proxyMethod.setAccessible(true);
        return proxyMethod.invoke(this.proxy, args);
      } catch (InvocationTargetException e) {
        throw new RuntimeException(e);
      } catch (IllegalAccessException e) {
        throw new InvocationError(e);
      } 
    }
  }
}
