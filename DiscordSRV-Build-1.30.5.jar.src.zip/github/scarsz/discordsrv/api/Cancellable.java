package github.scarsz.discordsrv.api;

public interface Cancellable {
  boolean isCancelled();
  
  void setCancelled(boolean paramBoolean);
}
