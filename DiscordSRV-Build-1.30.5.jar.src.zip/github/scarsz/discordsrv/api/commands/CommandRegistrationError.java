package github.scarsz.discordsrv.api.commands;

import github.scarsz.discordsrv.dependencies.jda.api.entities.Guild;

public final class CommandRegistrationError {
  private final Guild guild;
  
  private final Throwable exception;
  
  public CommandRegistrationError(Guild guild, Throwable exception) {
    this.guild = guild;
    this.exception = exception;
  }
  
  public Guild getGuild() {
    return this.guild;
  }
  
  public Throwable getException() {
    return this.exception;
  }
  
  public String toString() {
    return "CommandRegistrationError(guild=" + getGuild() + ", exception=" + getException() + ")";
  }
}
