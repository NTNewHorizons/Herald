package github.scarsz.discordsrv.api.commands;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Repeatable(SlashCommands.class)
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface SlashCommand {
  String path();
  
  SlashCommandPriority priority() default SlashCommandPriority.NORMAL;
  
  boolean deferReply() default false;
  
  boolean deferEphemeral() default false;
  
  boolean ignoreAcknowledged() default false;
}
