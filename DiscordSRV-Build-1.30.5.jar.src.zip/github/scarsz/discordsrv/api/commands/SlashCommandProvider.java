package github.scarsz.discordsrv.api.commands;

import java.util.Set;

public interface SlashCommandProvider {
  Set<PluginSlashCommand> getSlashCommands();
}
