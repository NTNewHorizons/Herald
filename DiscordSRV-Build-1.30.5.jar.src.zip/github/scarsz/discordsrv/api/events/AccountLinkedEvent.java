package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.dependencies.jda.api.entities.User;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

public class AccountLinkedEvent extends Event {
  private final OfflinePlayer player;
  
  private final User user;
  
  public AccountLinkedEvent(User user, UUID playerUuid) {
    this.player = Bukkit.getOfflinePlayer(playerUuid);
    this.user = user;
  }
  
  public OfflinePlayer getPlayer() {
    return this.player;
  }
  
  public User getUser() {
    return this.user;
  }
}
