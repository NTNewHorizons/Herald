package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.dependencies.jda.api.entities.User;
import github.scarsz.discordsrv.util.DiscordUtil;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

public class AccountUnlinkedEvent extends Event {
  private final OfflinePlayer player;
  
  private final String discordId;
  
  private final User discordUser;
  
  public AccountUnlinkedEvent(String discordId, UUID playerUuid) {
    this.player = Bukkit.getOfflinePlayer(playerUuid);
    this.discordId = discordId;
    this.discordUser = DiscordUtil.getUserById(discordId);
  }
  
  public OfflinePlayer getPlayer() {
    return this.player;
  }
  
  public String getDiscordId() {
    return this.discordId;
  }
  
  public User getDiscordUser() {
    return this.discordUser;
  }
}
