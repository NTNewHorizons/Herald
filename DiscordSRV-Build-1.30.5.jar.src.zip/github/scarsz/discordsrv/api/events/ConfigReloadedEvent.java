package github.scarsz.discordsrv.api.events;

import org.bukkit.command.CommandSender;

public class ConfigReloadedEvent extends Event {
  private final CommandSender requester;
  
  public ConfigReloadedEvent(CommandSender requester) {
    this.requester = requester;
  }
  
  public CommandSender getRequester() {
    return this.requester;
  }
}
