package github.scarsz.discordsrv.api.events;

public class DebugReportedEvent extends Event {
  private final String requester;
  
  private final String url;
  
  public DebugReportedEvent(String requester, String url) {
    this.requester = requester;
    this.url = url;
  }
  
  public String getRequester() {
    return this.requester;
  }
  
  public String getUrl() {
    return this.url;
  }
}
