package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.Cancellable;
import github.scarsz.discordsrv.dependencies.jda.api.JDA;
import github.scarsz.discordsrv.dependencies.jda.api.events.message.guild.GuildMessageReceivedEvent;

public class DiscordConsoleCommandPreProcessEvent extends DiscordEvent<GuildMessageReceivedEvent> implements Cancellable {
  private boolean sentInConsoleChannel;
  
  private boolean cancelled;
  
  private String command;
  
  public DiscordConsoleCommandPreProcessEvent(GuildMessageReceivedEvent jdaEvent, String command, boolean sentInConsoleChannel) {
    super(jdaEvent.getJDA(), jdaEvent);
    this.sentInConsoleChannel = sentInConsoleChannel;
    this.cancelled = false;
    this.command = command;
  }
  
  public boolean isSentInConsoleChannel() {
    return this.sentInConsoleChannel;
  }
  
  public boolean isCancelled() {
    return this.cancelled;
  }
  
  public String getCommand() {
    return this.command;
  }
  
  public void setCancelled(boolean cancelled) {
    this.cancelled = cancelled;
  }
  
  public void setCommand(String command) {
    this.command = command;
  }
}
