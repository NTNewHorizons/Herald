package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.dependencies.jda.api.JDA;

abstract class DiscordEvent<T> extends Event {
  private final JDA jda;
  
  private final T rawEvent;
  
  DiscordEvent(JDA jda) {
    this.jda = jda;
    this.rawEvent = null;
  }
  
  DiscordEvent(JDA jda, T rawEvent) {
    this.jda = jda;
    this.rawEvent = rawEvent;
  }
  
  public JDA getJda() {
    return this.jda;
  }
  
  public T getRawEvent() {
    return this.rawEvent;
  }
}
