package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.dependencies.kyori.adventure.text.Component;
import github.scarsz.discordsrv.util.MessageUtil;

public class DiscordGuildMessagePostBroadcastEvent extends Event {
  private final String channel;
  
  private final Component message;
  
  @Deprecated
  public DiscordGuildMessagePostBroadcastEvent(String channel, String processedMessage) {
    this.channel = channel;
    this.message = MessageUtil.toComponent(processedMessage);
  }
  
  public DiscordGuildMessagePostBroadcastEvent(String channel, Component message) {
    this.channel = channel;
    this.message = message;
  }
  
  @Deprecated
  public String getProcessedMessage() {
    return MessageUtil.toLegacy(this.message);
  }
  
  public String getChannel() {
    return this.channel;
  }
  
  public Component getMessage() {
    return this.message;
  }
}
