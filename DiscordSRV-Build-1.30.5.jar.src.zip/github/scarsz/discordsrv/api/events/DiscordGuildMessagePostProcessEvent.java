package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.Cancellable;
import github.scarsz.discordsrv.dependencies.jda.api.JDA;
import github.scarsz.discordsrv.dependencies.jda.api.entities.Guild;
import github.scarsz.discordsrv.dependencies.jda.api.entities.Member;
import github.scarsz.discordsrv.dependencies.jda.api.entities.Message;
import github.scarsz.discordsrv.dependencies.jda.api.entities.TextChannel;
import github.scarsz.discordsrv.dependencies.jda.api.entities.User;
import github.scarsz.discordsrv.dependencies.jda.api.events.message.guild.GuildMessageReceivedEvent;
import github.scarsz.discordsrv.dependencies.kyori.adventure.text.Component;
import github.scarsz.discordsrv.util.MessageUtil;

public class DiscordGuildMessagePostProcessEvent extends DiscordEvent<GuildMessageReceivedEvent> implements Cancellable {
  private boolean cancelled;
  
  private final User author;
  
  private final TextChannel channel;
  
  private final Guild guild;
  
  private final Member member;
  
  private final Message message;
  
  private Component minecraftMessage;
  
  @Deprecated
  public DiscordGuildMessagePostProcessEvent(GuildMessageReceivedEvent jdaEvent, boolean cancelled, String processedMessage) {
    super(jdaEvent.getJDA(), jdaEvent);
    this.author = jdaEvent.getAuthor();
    this.channel = jdaEvent.getChannel();
    this.guild = jdaEvent.getGuild();
    this.member = jdaEvent.getMember();
    this.message = jdaEvent.getMessage();
    setCancelled(cancelled);
    setProcessedMessage(processedMessage);
  }
  
  public DiscordGuildMessagePostProcessEvent(GuildMessageReceivedEvent jdaEvent, boolean cancelled, Component minecraftMessage) {
    super(jdaEvent.getJDA(), jdaEvent);
    this.author = jdaEvent.getAuthor();
    this.channel = jdaEvent.getChannel();
    this.guild = jdaEvent.getGuild();
    this.member = jdaEvent.getMember();
    this.message = jdaEvent.getMessage();
    setCancelled(cancelled);
    this.minecraftMessage = minecraftMessage;
  }
  
  @Deprecated
  public void setProcessedMessage(String processedMessage) {
    this.minecraftMessage = MessageUtil.toComponent(processedMessage);
  }
  
  @Deprecated
  public String getProcessedMessage() {
    return MessageUtil.toLegacy(this.minecraftMessage);
  }
  
  public boolean isCancelled() {
    return this.cancelled;
  }
  
  public User getAuthor() {
    return this.author;
  }
  
  public TextChannel getChannel() {
    return this.channel;
  }
  
  public Guild getGuild() {
    return this.guild;
  }
  
  public Member getMember() {
    return this.member;
  }
  
  public Message getMessage() {
    return this.message;
  }
  
  public Component getMinecraftMessage() {
    return this.minecraftMessage;
  }
  
  public void setCancelled(boolean cancelled) {
    this.cancelled = cancelled;
  }
  
  public void setMinecraftMessage(Component minecraftMessage) {
    this.minecraftMessage = minecraftMessage;
  }
}
