package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.dependencies.jda.api.entities.User;
import github.scarsz.discordsrv.dependencies.kyori.adventure.text.Component;
import java.util.List;
import org.bukkit.command.CommandSender;

public class DiscordGuildMessagePreBroadcastEvent extends Event {
  private final User author;
  
  private String channel;
  
  private Component message;
  
  private final List<? extends CommandSender> recipients;
  
  public DiscordGuildMessagePreBroadcastEvent(User author, String channel, Component message, List<? extends CommandSender> recipients) {
    this.author = author;
    this.channel = channel;
    this.message = message;
    this.recipients = recipients;
  }
  
  public User getAuthor() {
    return this.author;
  }
  
  public String getChannel() {
    return this.channel;
  }
  
  public Component getMessage() {
    return this.message;
  }
  
  public List<? extends CommandSender> getRecipients() {
    return this.recipients;
  }
  
  public void setChannel(String channel) {
    this.channel = channel;
  }
  
  public void setMessage(Component message) {
    this.message = message;
  }
}
