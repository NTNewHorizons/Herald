package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.Cancellable;
import github.scarsz.discordsrv.dependencies.jda.api.JDA;
import github.scarsz.discordsrv.dependencies.jda.api.entities.Guild;
import github.scarsz.discordsrv.dependencies.jda.api.entities.Member;
import github.scarsz.discordsrv.dependencies.jda.api.entities.Message;
import github.scarsz.discordsrv.dependencies.jda.api.entities.TextChannel;
import github.scarsz.discordsrv.dependencies.jda.api.entities.User;
import github.scarsz.discordsrv.dependencies.jda.api.events.message.guild.GuildMessageReceivedEvent;

public class DiscordGuildMessagePreProcessEvent extends DiscordEvent<GuildMessageReceivedEvent> implements Cancellable {
  private boolean cancelled;
  
  private final User author;
  
  private final TextChannel channel;
  
  private final Guild guild;
  
  private final Member member;
  
  private final Message message;
  
  public DiscordGuildMessagePreProcessEvent(GuildMessageReceivedEvent jdaEvent) {
    super(jdaEvent.getJDA(), jdaEvent);
    this.author = jdaEvent.getAuthor();
    this.channel = jdaEvent.getChannel();
    this.guild = jdaEvent.getGuild();
    this.member = jdaEvent.getMember();
    this.message = jdaEvent.getMessage();
  }
  
  public boolean isCancelled() {
    return this.cancelled;
  }
  
  public User getAuthor() {
    return this.author;
  }
  
  public TextChannel getChannel() {
    return this.channel;
  }
  
  public Guild getGuild() {
    return this.guild;
  }
  
  public Member getMember() {
    return this.member;
  }
  
  public Message getMessage() {
    return this.message;
  }
  
  public void setCancelled(boolean cancelled) {
    this.cancelled = cancelled;
  }
}
