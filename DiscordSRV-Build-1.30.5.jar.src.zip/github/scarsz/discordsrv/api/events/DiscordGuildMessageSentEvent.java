package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.dependencies.jda.api.JDA;
import github.scarsz.discordsrv.dependencies.jda.api.entities.Guild;
import github.scarsz.discordsrv.dependencies.jda.api.entities.Message;
import github.scarsz.discordsrv.dependencies.jda.api.entities.TextChannel;

public class DiscordGuildMessageSentEvent extends DiscordEvent {
  private final TextChannel channel;
  
  private final Guild guild;
  
  private final Message message;
  
  public DiscordGuildMessageSentEvent(JDA jda, Message message) {
    super(jda);
    this.channel = message.getTextChannel();
    this.guild = message.getGuild();
    this.message = message;
  }
  
  public TextChannel getChannel() {
    return this.channel;
  }
  
  public Guild getGuild() {
    return this.guild;
  }
  
  public Message getMessage() {
    return this.message;
  }
}
