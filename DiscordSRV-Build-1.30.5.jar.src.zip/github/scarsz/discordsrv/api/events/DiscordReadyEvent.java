package github.scarsz.discordsrv.api.events;

public class DiscordReadyEvent extends Event {}
