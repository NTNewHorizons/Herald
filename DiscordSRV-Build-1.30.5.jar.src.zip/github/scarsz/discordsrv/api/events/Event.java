package github.scarsz.discordsrv.api.events;

public abstract class Event {}
