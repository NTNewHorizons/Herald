package github.scarsz.discordsrv.api.events;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;

public class GameChatMessagePostProcessEvent extends GameEvent<Event> implements Cancellable {
  private boolean cancelled;
  
  private String channel;
  
  private String processedMessage;
  
  public GameChatMessagePostProcessEvent(String channel, String processedMessage, Player player, boolean cancelled, Event event) {
    super(player, event);
    this.channel = channel;
    this.processedMessage = processedMessage;
    setCancelled(cancelled);
  }
  
  @Deprecated
  public GameChatMessagePostProcessEvent(String channel, String processedMessage, Player player, boolean cancelled) {
    this(channel, processedMessage, player, cancelled, null);
  }
  
  public boolean isCancelled() {
    return this.cancelled;
  }
  
  public String getChannel() {
    return this.channel;
  }
  
  public String getProcessedMessage() {
    return this.processedMessage;
  }
  
  public void setCancelled(boolean cancelled) {
    this.cancelled = cancelled;
  }
  
  public void setChannel(String channel) {
    this.channel = channel;
  }
  
  public void setProcessedMessage(String processedMessage) {
    this.processedMessage = processedMessage;
  }
}
