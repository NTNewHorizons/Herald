package github.scarsz.discordsrv.api.events;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;

abstract class GameEvent<T extends Event> extends Event {
  private final Player player;
  
  private final T triggeringBukkitEvent;
  
  GameEvent(Player player, T triggeringBukkitEvent) {
    this.player = player;
    this.triggeringBukkitEvent = triggeringBukkitEvent;
  }
  
  public Player getPlayer() {
    return this.player;
  }
  
  public T getTriggeringBukkitEvent() {
    return this.triggeringBukkitEvent;
  }
}
