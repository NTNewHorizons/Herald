package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.Cancellable;
import github.scarsz.discordsrv.dependencies.jda.api.entities.Guild;
import github.scarsz.discordsrv.dependencies.jda.api.interactions.commands.build.CommandData;
import java.util.Set;

public class GuildSlashCommandUpdateEvent extends Event implements Cancellable {
  private boolean cancelled;
  
  private final Guild guild;
  
  private final Set<CommandData> commands;
  
  public GuildSlashCommandUpdateEvent(Guild guild, Set<CommandData> commands) {
    this.guild = guild;
    this.commands = commands;
  }
  
  public boolean isCancelled() {
    return this.cancelled;
  }
  
  public Guild getGuild() {
    return this.guild;
  }
  
  public Set<CommandData> getCommands() {
    return this.commands;
  }
  
  public void setCancelled(boolean cancelled) {
    this.cancelled = cancelled;
  }
}
