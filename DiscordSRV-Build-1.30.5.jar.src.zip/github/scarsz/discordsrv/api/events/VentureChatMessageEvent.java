package github.scarsz.discordsrv.api.events;

import mineverse.Aust1n46.chat.api.events.VentureChatEvent;

abstract class VentureChatMessageEvent extends Event {
  private final VentureChatEvent ventureChatEvent;
  
  VentureChatMessageEvent(VentureChatEvent ventureChatEvent) {
    this.ventureChatEvent = ventureChatEvent;
  }
  
  public VentureChatEvent getVentureChatEvent() {
    return this.ventureChatEvent;
  }
}
