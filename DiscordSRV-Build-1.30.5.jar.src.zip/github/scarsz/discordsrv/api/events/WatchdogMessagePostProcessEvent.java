package github.scarsz.discordsrv.api.events;

import org.bukkit.event.Cancellable;

public class WatchdogMessagePostProcessEvent extends Event implements Cancellable {
  private boolean cancelled;
  
  private String channel;
  
  private String processedMessage;
  
  private int count;
  
  public WatchdogMessagePostProcessEvent(String channel, String processedMessage, int count, boolean cancelled) {
    this.channel = channel;
    this.count = count;
    this.processedMessage = processedMessage;
    setCancelled(cancelled);
  }
  
  public boolean isCancelled() {
    return this.cancelled;
  }
  
  public String getChannel() {
    return this.channel;
  }
  
  public String getProcessedMessage() {
    return this.processedMessage;
  }
  
  public int getCount() {
    return this.count;
  }
  
  public void setCancelled(boolean cancelled) {
    this.cancelled = cancelled;
  }
  
  public void setChannel(String channel) {
    this.channel = channel;
  }
  
  public void setProcessedMessage(String processedMessage) {
    this.processedMessage = processedMessage;
  }
  
  public void setCount(int count) {
    this.count = count;
  }
}
