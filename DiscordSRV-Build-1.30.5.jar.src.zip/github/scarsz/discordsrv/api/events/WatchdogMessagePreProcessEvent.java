package github.scarsz.discordsrv.api.events;

import org.bukkit.event.Cancellable;

public class WatchdogMessagePreProcessEvent extends Event implements Cancellable {
  private boolean cancelled;
  
  private String channel;
  
  private String message;
  
  private int count;
  
  public WatchdogMessagePreProcessEvent(String channel, String message, int count, boolean cancelled) {
    this.channel = channel;
    this.count = count;
    this.message = message;
    setCancelled(cancelled);
  }
  
  public boolean isCancelled() {
    return this.cancelled;
  }
  
  public String getChannel() {
    return this.channel;
  }
  
  public String getMessage() {
    return this.message;
  }
  
  public int getCount() {
    return this.count;
  }
  
  public void setCancelled(boolean cancelled) {
    this.cancelled = cancelled;
  }
  
  public void setChannel(String channel) {
    this.channel = channel;
  }
  
  public void setMessage(String message) {
    this.message = message;
  }
  
  public void setCount(int count) {
    this.count = count;
  }
}
