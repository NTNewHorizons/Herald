package github.scarsz.discordsrv.commands;

import github.scarsz.configuralize.Language;
import github.scarsz.configuralize.Provider;
import github.scarsz.configuralize.Source;
import github.scarsz.discordsrv.DiscordSRV;
import github.scarsz.discordsrv.dependencies.commons.io.FileUtils;
import github.scarsz.discordsrv.dependencies.commons.lang3.StringUtils;
import github.scarsz.discordsrv.dependencies.kyori.adventure.text.Component;
import github.scarsz.discordsrv.dependencies.kyori.adventure.text.TextComponent;
import github.scarsz.discordsrv.dependencies.kyori.adventure.text.event.ClickEvent;
import github.scarsz.discordsrv.dependencies.kyori.adventure.text.event.HoverEvent;
import github.scarsz.discordsrv.dependencies.kyori.adventure.text.event.HoverEventSource;
import github.scarsz.discordsrv.dependencies.kyori.adventure.text.format.NamedTextColor;
import github.scarsz.discordsrv.dependencies.kyori.adventure.text.format.TextColor;
import github.scarsz.discordsrv.util.MessageUtil;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class CommandLanguage {
  @Command(commandNames = {"language", "setlanguage", "lang", "setlang"}, helpMessage = "Changes the language of DiscordSRV to whatever is specified.", permission = "discordsrv.language", usageExample = "language japanese")
  public static void execute(CommandSender sender, String[] args) throws IOException {
    Language currentLanguage = DiscordSRV.config().getLanguage();
    String currentLanguageName = StringUtils.capitalize(currentLanguage.getName().toLowerCase());
    Language targetLanguage = null;
    label40: for (String arg : args) {
      for (Language language : Language.values()) {
        if (language.getCode().equalsIgnoreCase(arg) || language.getName().equalsIgnoreCase(arg)) {
          targetLanguage = language;
          break label40;
        } 
      } 
    } 
    if (targetLanguage == null) {
      MessageUtil.sendMessage(sender, ChatColor.DARK_AQUA + "DiscordSRV is currently in " + currentLanguageName + ". Change it by giving a language as an argument.");
      return;
    } 
    String targetLanguageName = StringUtils.capitalize(targetLanguage.getName().toLowerCase());
    if (!DiscordSRV.config().isLanguageAvailable(targetLanguage)) {
      Objects.requireNonNull(DiscordSRV.config());
      String available = Arrays.<Language>stream(Language.values()).filter(DiscordSRV.config()::isLanguageAvailable).map(language -> StringUtils.capitalize(language.getName().toLowerCase())).collect(Collectors.joining(", "));
      MessageUtil.sendMessage(sender, ChatColor.DARK_AQUA + "DiscordSRV does not have a translation for " + targetLanguageName + ". Supported languages are as follows: " + available + ".");
      return;
    } 
    if (Arrays.<String>stream(args).noneMatch(s -> s.equalsIgnoreCase("-confirm"))) {
      TextComponent message = (TextComponent)((TextComponent)((TextComponent)((TextComponent)((TextComponent)Component.text("This will reset your DiscordSRV configuration files to be in ", (TextColor)NamedTextColor.DARK_AQUA).append((Component)Component.text(targetLanguageName, (TextColor)NamedTextColor.WHITE))).append((Component)Component.text(". Your old config files will be renamed to have ", (TextColor)NamedTextColor.DARK_AQUA))).append((Component)Component.text(currentLanguageName + ".", (TextColor)NamedTextColor.WHITE))).append((Component)Component.text(" on the beginning of the file name. "))).append(((TextComponent)((TextComponent)Component.text("[Confirm" + ((sender instanceof org.bukkit.entity.Player) ? "?" : " by running the command again, adding \" -confirm\" to the end") + "]")
          .color((TextColor)NamedTextColor.GREEN))
          .clickEvent(ClickEvent.runCommand("/discord language " + targetLanguage.getCode() + " -confirm")))
          .hoverEvent((HoverEventSource)HoverEvent.showText((Component)Component.text("Click to confirm the config change.", (TextColor)NamedTextColor.GREEN))));
      MessageUtil.sendMessage(sender, (Component)message);
    } else {
      DiscordSRV.config().setLanguage(targetLanguage);
      for (Map.Entry<Source, Provider> entry : (Iterable<Map.Entry<Source, Provider>>)DiscordSRV.config().getSources().entrySet()) {
        File source = ((Source)entry.getKey()).getFile();
        File target = new File(source.getParentFile(), currentLanguageName + "." + source.getName());
        FileUtils.moveFile(source, target);
        ((Provider)entry.getValue()).saveDefaults();
        if (((Source)entry.getKey()).getResourceName().equals("config")) {
          String file = FileUtils.readFileToString(source, "UTF-8");
          file = file.replace("\nForcedLanguage: none", "\nForcedLanguage: " + targetLanguageName);
          FileUtils.writeStringToFile(source, file, "UTF-8");
        } 
      } 
      MessageUtil.sendMessage(sender, ChatColor.DARK_AQUA + "DiscordSRV language successfully changed to " + targetLanguageName + ".");
    } 
  }
}
