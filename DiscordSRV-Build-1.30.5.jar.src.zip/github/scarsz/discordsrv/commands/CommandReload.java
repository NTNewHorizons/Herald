package github.scarsz.discordsrv.commands;

import github.scarsz.discordsrv.DiscordSRV;
import github.scarsz.discordsrv.api.events.ConfigReloadedEvent;
import github.scarsz.discordsrv.api.events.Event;
import github.scarsz.discordsrv.hooks.PluginHook;
import github.scarsz.discordsrv.hooks.chat.TownyChatHook;
import github.scarsz.discordsrv.util.LangUtil;
import github.scarsz.discordsrv.util.MessageUtil;
import github.scarsz.discordsrv.util.SchedulerUtil;
import github.scarsz.discordsrv.util.UpdateUtil;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;

public class CommandReload {
  @Command(commandNames = {"reload"}, helpMessage = "Reloads the config of DiscordSRV", permission = "discordsrv.reload")
  public static void execute(CommandSender sender, String[] args) {
    DiscordSRV.getPlugin().reloadConfig();
    DiscordSRV.getPlugin().reloadCancellationDetector();
    DiscordSRV.getPlugin().reloadChannels();
    DiscordSRV.getPlugin().reloadRegexes();
    DiscordSRV.getPlugin().reloadRoleAliases();
    DiscordSRV.getPlugin().reloadAllowedMentions();
    DiscordSRV.api.updateSlashCommands();
    if (DiscordSRV.getPlugin().getChannelUpdater() != null)
      DiscordSRV.getPlugin().getChannelUpdater().reload(); 
    if (DiscordSRV.getPlugin().getAlertListener() != null)
      DiscordSRV.getPlugin().getAlertListener().reloadAlerts(); 
    DiscordSRV.getPlugin().getPluginHooks().stream()
      .filter(hook -> hook instanceof TownyChatHook)
      .forEach(hook -> ((TownyChatHook)hook).reload());
    if (!DiscordSRV.isUpdateCheckDisabled() && !DiscordSRV.updateChecked) {
      SchedulerUtil.runTaskAsynchronously((Plugin)DiscordSRV.getPlugin(), UpdateUtil::checkForUpdates);
      DiscordSRV.updateChecked = true;
    } 
    MessageUtil.sendMessage(sender, ChatColor.AQUA + LangUtil.InternalMessage.RELOADED.toString());
    DiscordSRV.api.callEvent((Event)new ConfigReloadedEvent(sender));
  }
}
