package github.scarsz.discordsrv.dependencies.alexh;

import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class Unchecker {
  private static final Function<Throwable, ? extends RuntimeException> DEFAULT_EXCEPTION_TRANSFORMER = RuntimeException::new;
  
  public static <T> Supplier<T> uncheck(ThrowingSupplier<T> supplier, Function<Throwable, ? extends RuntimeException> exTransformer) {
    return () -> {
        try {
          return supplier.get();
        } catch (RuntimeException|Error e) {
          throw e;
        } catch (Throwable t) {
          throw (RuntimeException)exTransformer.apply(t);
        } 
      };
  }
  
  public static <T> T uncheckedGet(ThrowingSupplier<T> supplier, Function<Throwable, ? extends RuntimeException> exTransformer) {
    return uncheck(supplier, exTransformer).get();
  }
  
  public static void unchecked(ThrowingRunnable runnable, Function<Throwable, ? extends RuntimeException> exTransformer) {
    uncheck(runnable, exTransformer).run();
  }
  
  public static <In, Out> Function<In, Out> uncheck(ThrowingFunction<In, Out> function, Function<Throwable, ? extends RuntimeException> exTransformer) {
    return in -> uncheckedGet((), exTransformer);
  }
  
  public static <In1, In2, Out> BiFunction<In1, In2, Out> uncheck(ThrowingBiFunction<In1, In2, Out> function, Function<Throwable, ? extends RuntimeException> exTransformer) {
    return (in1, in2) -> uncheckedGet((), exTransformer);
  }
  
  public static Runnable uncheck(ThrowingRunnable runnable, Function<Throwable, ? extends RuntimeException> exTransformer) {
    return () -> uncheckedGet((), exTransformer);
  }
  
  public static <T> Consumer<T> uncheck(ThrowingConsumer<T> consumer, Function<Throwable, ? extends RuntimeException> exTransformer) {
    return t -> unchecked((), exTransformer);
  }
  
  public static <T, U> BiConsumer<T, U> uncheck(ThrowingBiConsumer<T, U> consumer, Function<Throwable, ? extends RuntimeException> exTransformer) {
    return (t, u) -> unchecked((), exTransformer);
  }
  
  public static <T> Supplier<T> uncheck(ThrowingSupplier<T> supplier) {
    return uncheck(supplier, DEFAULT_EXCEPTION_TRANSFORMER);
  }
  
  public static <T> T uncheckedGet(ThrowingSupplier<T> supplier) {
    return uncheckedGet(supplier, DEFAULT_EXCEPTION_TRANSFORMER);
  }
  
  public static void unchecked(ThrowingRunnable runnable) {
    unchecked(runnable, DEFAULT_EXCEPTION_TRANSFORMER);
  }
  
  public static <In, Out> Function<In, Out> uncheck(ThrowingFunction<In, Out> function) {
    return uncheck(function, DEFAULT_EXCEPTION_TRANSFORMER);
  }
  
  public static <In1, In2, Out> BiFunction<In1, In2, Out> uncheck(ThrowingBiFunction<In1, In2, Out> function) {
    return uncheck(function, DEFAULT_EXCEPTION_TRANSFORMER);
  }
  
  public static Runnable uncheck(ThrowingRunnable runnable) {
    return uncheck(runnable, DEFAULT_EXCEPTION_TRANSFORMER);
  }
  
  public static <T> Consumer<T> uncheck(ThrowingConsumer<T> consumer) {
    return uncheck(consumer, DEFAULT_EXCEPTION_TRANSFORMER);
  }
  
  public static <T, U> BiConsumer<T, U> uncheck(ThrowingBiConsumer<T, U> consumer) {
    return uncheck(consumer, DEFAULT_EXCEPTION_TRANSFORMER);
  }
  
  @FunctionalInterface
  public static interface ThrowingBiConsumer<T, U> {
    void accept(T param1T, U param1U) throws Throwable;
  }
  
  @FunctionalInterface
  public static interface ThrowingConsumer<T> {
    void accept(T param1T) throws Throwable;
  }
  
  @FunctionalInterface
  public static interface ThrowingBiFunction<In1, In2, Out> {
    Out apply(In1 param1In1, In2 param1In2) throws Throwable;
  }
  
  @FunctionalInterface
  public static interface ThrowingFunction<In, Out> {
    Out apply(In param1In) throws Throwable;
  }
  
  @FunctionalInterface
  public static interface ThrowingRunnable {
    void run() throws Throwable;
  }
  
  @FunctionalInterface
  public static interface ThrowingSupplier<T> {
    T get() throws Throwable;
  }
}
