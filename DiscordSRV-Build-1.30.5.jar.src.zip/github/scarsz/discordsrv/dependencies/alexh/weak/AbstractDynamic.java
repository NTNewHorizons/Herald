package github.scarsz.discordsrv.dependencies.alexh.weak;

public abstract class AbstractDynamic<T> implements Dynamic {
  protected final T inner;
  
  public AbstractDynamic(T inner) {
    this.inner = inner;
  }
  
  public boolean isPresent() {
    return true;
  }
  
  public Object asObject() {
    return this.inner;
  }
  
  public int hashCode() {
    return this.inner.hashCode();
  }
  
  public Dynamic key() {
    return DynamicChild.key(this, keyLiteral());
  }
  
  public boolean equals(Object o) {
    if (this == o)
      return true; 
    if (o == null || getClass() != o.getClass())
      return false; 
    AbstractDynamic other = (AbstractDynamic)o;
    return this.inner.equals(other.inner);
  }
  
  protected abstract Object keyLiteral();
}
