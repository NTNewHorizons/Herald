package github.scarsz.discordsrv.dependencies.alexh.weak;

import java.util.Iterator;
import java.util.stream.Stream;

class BreadthChildIterator implements Iterator<Dynamic> {
  private final Dynamic root;
  
  private int depth;
  
  private Iterator<Dynamic> current;
  
  BreadthChildIterator(Dynamic root) {
    this.root = root;
    this.depth = 1;
    this.current = root.children().iterator();
  }
  
  private Stream<Dynamic> nextDepth() {
    Stream<Dynamic> childrenAtNextDepth = this.root.children();
    int nextDepth = 1;
    while (nextDepth <= this.depth) {
      childrenAtNextDepth = childrenAtNextDepth.flatMap(Dynamic::children);
      nextDepth++;
    } 
    return childrenAtNextDepth;
  }
  
  private boolean moveDepthIfAvailable() {
    Iterator<Dynamic> nextDepth = nextDepth().iterator();
    if (nextDepth.hasNext()) {
      this.current = nextDepth;
      this.depth++;
      return true;
    } 
    return false;
  }
  
  public boolean hasNext() {
    return (this.current.hasNext() || moveDepthIfAvailable());
  }
  
  public Dynamic next() {
    if (!this.current.hasNext())
      moveDepthIfAvailable(); 
    return this.current.next();
  }
}
