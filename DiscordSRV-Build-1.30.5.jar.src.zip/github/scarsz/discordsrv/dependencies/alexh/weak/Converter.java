package github.scarsz.discordsrv.dependencies.alexh.weak;

import github.scarsz.discordsrv.dependencies.alexh.Fluent;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class Converter {
  private static final String DEFAULT_MAP_KEY = "value";
  
  private static final Map<Class<?>, Function<Object, ? extends Converter>> typeConverters;
  
  protected final Object o;
  
  static {
    typeConverters = Collections.unmodifiableMap((Map<? extends Class<?>, ? extends Function<Object, ? extends Converter>>)(new Fluent.LinkedHashMap())
        
        .append(Integer.class, IntConverter::new)
        .append(Long.class, LongConverter::new)
        .append(Double.class, DoubleConverter::new)
        .append(BigDecimal.class, DecimalConverter::new)
        .append(Weak.class, o -> convert(((Weak)o).asObject()))
        .append(OptionalWeak.class, o -> new OptionalConverter(((OptionalWeak)o).asObject()))
        .append(Map.class, MapConverter::new)
        .append(Iterable.class, IterableConverter::new)
        .append(Optional.class, OptionalConverter::new)
        .append(Date.class, UtilDateInstantConverter::new)
        
        .append(Object.class, Converter::new));
  }
  
  public static Converter convert(Object value) {
    Objects.requireNonNull(value);
    if (value instanceof Object[])
      return convert(Arrays.asList((Object[])value)); 
    return ((Function<Object, Converter>)typeConverters.getOrDefault(value.getClass(), typeConverters.entrySet().stream()
        .filter(entry -> (!((Class)entry.getKey()).equals(Date.class) && ((Class)entry.getKey()).isInstance(value)))
        .findFirst()
        .map(Map.Entry::getValue).get())).apply(value);
  }
  
  private static boolean doesNotThrow(Supplier<?> method) {
    try {
      method.get();
      return true;
    } catch (RuntimeException ex) {
      return false;
    } 
  }
  
  Converter(Object o) {
    this.o = o;
  }
  
  public String intoString() {
    return (this.o instanceof String) ? (String)this.o : this.o.toString();
  }
  
  public boolean intoStringWorks() {
    return doesNotThrow(this::intoString);
  }
  
  public int intoInteger() {
    return intoDecimal().setScale(0, RoundingMode.HALF_UP).intValueExact();
  }
  
  public boolean intoIntegerWorks() {
    return doesNotThrow(this::intoInteger);
  }
  
  public long intoLong() {
    return intoDecimal().setScale(0, RoundingMode.HALF_UP).longValueExact();
  }
  
  public boolean intoLongWorks() {
    return doesNotThrow(this::intoLong);
  }
  
  public double intoDouble() {
    return intoDecimal().doubleValue();
  }
  
  public boolean intoDoubleWorks() {
    return doesNotThrow(this::intoDouble);
  }
  
  public BigDecimal intoDecimal() {
    return new BigDecimal(intoString());
  }
  
  public boolean intoDecimalWorks() {
    return doesNotThrow(this::intoDecimal);
  }
  
  public Map intoMap() {
    return (Map)(new Fluent.HashMap()).append("value", this.o);
  }
  
  public boolean intoMapWorks() {
    return doesNotThrow(this::intoMap);
  }
  
  public List intoList() {
    List<Object> list = new ArrayList();
    list.add(this.o);
    return list;
  }
  
  public boolean intoListWorks() {
    return doesNotThrow(this::intoList);
  }
  
  public LocalDateTime intoLocalDateTime() {
    return LocalDateTime.from(ConverterTimeFormats.parseWithDefaults(intoString()));
  }
  
  public boolean intoLocalDateTimeWorks() {
    return doesNotThrow(this::intoLocalDateTime);
  }
  
  public ZonedDateTime intoZonedDateTime() {
    return ZonedDateTime.from(ConverterTimeFormats.parseWithDefaults(intoString()));
  }
  
  public boolean intoZonedDateTimeWorks() {
    return doesNotThrow(this::intoZonedDateTime);
  }
  
  public ZonedDateTime intoZonedDateTimeOrUse(ZoneId fallback) {
    try {
      return intoZonedDateTime();
    } catch (RuntimeException ex) {
      return intoLocalDateTime().atZone(fallback);
    } 
  }
  
  public ConverterMaybe maybe() {
    return new ConverterMaybe(this.o);
  }
  
  static abstract class TypeConverter<T> extends Converter {
    TypeConverter(Object o) {
      super(o);
    }
    
    protected T literal() {
      return (T)this.o;
    }
  }
  
  static class IntConverter extends TypeConverter<Integer> {
    IntConverter(Object o) {
      super(o);
    }
    
    public int intoInteger() {
      return literal().intValue();
    }
    
    public long intoLong() {
      return literal().intValue();
    }
    
    public double intoDouble() {
      return literal().intValue();
    }
    
    public BigDecimal intoDecimal() {
      return new BigDecimal(literal().intValue());
    }
  }
  
  static class LongConverter extends TypeConverter<Long> {
    LongConverter(Object o) {
      super(o);
    }
    
    public int intoInteger() {
      if (literal().longValue() < -2147483648L || literal().longValue() > 2147483647L)
        throw new IllegalArgumentException(literal() + " too large/small to be cast to int"); 
      return literal().intValue();
    }
    
    public long intoLong() {
      return literal().longValue();
    }
    
    public double intoDouble() {
      return literal().longValue();
    }
    
    public BigDecimal intoDecimal() {
      return new BigDecimal(literal().longValue());
    }
  }
  
  static class DoubleConverter extends TypeConverter<Double> {
    DoubleConverter(Object o) {
      super(o);
    }
    
    public double intoDouble() {
      return literal().doubleValue();
    }
    
    public BigDecimal intoDecimal() {
      return new BigDecimal(literal().doubleValue());
    }
  }
  
  static class DecimalConverter extends TypeConverter<BigDecimal> {
    DecimalConverter(Object o) {
      super(o);
    }
    
    public BigDecimal intoDecimal() {
      return literal();
    }
  }
  
  static class MapConverter extends TypeConverter<Map<?, ?>> {
    MapConverter(Object o) {
      super(o);
    }
    
    private Optional<Object> value() {
      return Optional.ofNullable(literal().get("value"));
    }
    
    public String intoString() {
      return value().<String>map(o -> convert(o).intoString()).orElseGet(() -> super.intoString());
    }
    
    public int intoInteger() {
      return ((Integer)value().<Integer>map(o -> Integer.valueOf(convert(o).intoInteger())).orElseGet(() -> Integer.valueOf(super.intoInteger()))).intValue();
    }
    
    public long intoLong() {
      return ((Long)value().<Long>map(o -> Long.valueOf(convert(o).intoLong())).orElseGet(() -> Long.valueOf(super.intoLong()))).longValue();
    }
    
    public double intoDouble() {
      return ((Double)value().<Double>map(o -> Double.valueOf(convert(o).intoDouble())).orElseGet(() -> Double.valueOf(super.intoDouble()))).doubleValue();
    }
    
    public BigDecimal intoDecimal() {
      return value().<BigDecimal>map(o -> convert(o).intoDecimal()).orElseGet(() -> super.intoDecimal());
    }
    
    public Map intoMap() {
      return new LinkedHashMap<>(literal());
    }
    
    public List intoList() {
      return new ArrayList(literal().values());
    }
  }
  
  static class IterableConverter extends TypeConverter<Iterable<?>> {
    IterableConverter(Object o) {
      super(o);
    }
    
    private Optional<Object> onlyElement() {
      Iterator<?> iterator = literal().iterator();
      return Optional.<Object>ofNullable(iterator.hasNext() ? iterator.next() : null)
        .filter(o -> !iterator.hasNext());
    }
    
    public String intoString() {
      return onlyElement().<String>map(o -> convert(o).intoString()).orElseGet(() -> super.intoString());
    }
    
    public int intoInteger() {
      return ((Integer)onlyElement().<Integer>map(o -> Integer.valueOf(convert(o).intoInteger())).orElseGet(() -> Integer.valueOf(super.intoInteger()))).intValue();
    }
    
    public long intoLong() {
      return ((Long)onlyElement().<Long>map(o -> Long.valueOf(convert(o).intoLong())).orElseGet(() -> Long.valueOf(super.intoLong()))).longValue();
    }
    
    public double intoDouble() {
      return ((Double)onlyElement().<Double>map(o -> Double.valueOf(convert(o).intoDouble())).orElseGet(() -> Double.valueOf(super.intoDouble()))).doubleValue();
    }
    
    public BigDecimal intoDecimal() {
      return onlyElement().<BigDecimal>map(o -> convert(o).intoDecimal()).orElseGet(() -> super.intoDecimal());
    }
    
    public Map intoMap() {
      Map<Integer, Object> map = new LinkedHashMap<>();
      Iterator<?> iterator = literal().iterator();
      for (int i = 0; iterator.hasNext(); i++)
        map.put(Integer.valueOf(i), iterator.next()); 
      return map;
    }
    
    public List intoList() {
      return (List)StreamSupport.stream(literal().spliterator(), false).collect(Collectors.toCollection(ArrayList::new));
    }
  }
  
  static class OptionalConverter extends TypeConverter<Optional<?>> {
    OptionalConverter(Object o) {
      super(o);
    }
    
    public String intoString() {
      return literal().<String>map(o -> convert(o).intoString()).orElseGet(() -> super.intoString());
    }
    
    public int intoInteger() {
      return ((Integer)literal().<Integer>map(o -> Integer.valueOf(convert(o).intoInteger())).orElseGet(() -> Integer.valueOf(super.intoInteger()))).intValue();
    }
    
    public long intoLong() {
      return ((Long)literal().<Long>map(o -> Long.valueOf(convert(o).intoLong())).orElseGet(() -> Long.valueOf(super.intoLong()))).longValue();
    }
    
    public double intoDouble() {
      return ((Double)literal().<Double>map(o -> Double.valueOf(convert(o).intoDouble())).orElseGet(() -> Double.valueOf(super.intoDouble()))).doubleValue();
    }
    
    public BigDecimal intoDecimal() {
      return literal().<BigDecimal>map(o -> convert(o).intoDecimal()).orElseGet(() -> super.intoDecimal());
    }
    
    public Map intoMap() {
      return literal().<Map>map(o -> convert(o).intoMap()).orElseGet(LinkedHashMap::new);
    }
    
    public List intoList() {
      return literal().<List>map(o -> convert(o).intoList()).orElseGet(ArrayList::new);
    }
  }
  
  static class UtilDateInstantConverter extends TypeConverter<Date> {
    UtilDateInstantConverter(Object o) {
      super(o);
    }
    
    public BigDecimal intoDecimal() {
      return new BigDecimal(intoLong());
    }
    
    public double intoDouble() {
      return intoLong();
    }
    
    public long intoLong() {
      return literal().getTime();
    }
    
    public String intoString() {
      return String.valueOf(literal().getTime());
    }
  }
}
