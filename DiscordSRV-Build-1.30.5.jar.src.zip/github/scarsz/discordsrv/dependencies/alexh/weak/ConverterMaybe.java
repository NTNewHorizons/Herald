package github.scarsz.discordsrv.dependencies.alexh.weak;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

public class ConverterMaybe {
  protected final Object o;
  
  ConverterMaybe(Object o) {
    this.o = o;
  }
  
  private <T> Optional<T> optional(Function<Converter, T> fn) {
    try {
      return Optional.ofNullable(fn.apply(Converter.convert(this.o)));
    } catch (RuntimeException ex) {
      return Optional.empty();
    } 
  }
  
  public Optional<String> intoString() {
    return optional(Converter::intoString);
  }
  
  public Optional<Integer> intoInteger() {
    return optional(Converter::intoInteger);
  }
  
  public Optional<Long> intoLong() {
    return optional(Converter::intoLong);
  }
  
  public Optional<Double> intoDouble() {
    return optional(Converter::intoDouble);
  }
  
  public Optional<BigDecimal> intoDecimal() {
    return optional(Converter::intoDecimal);
  }
  
  public Optional<Map> intoMap() {
    return optional(Converter::intoMap);
  }
  
  public Optional<List> intoList() {
    return optional(Converter::intoList);
  }
  
  public Optional<LocalDateTime> intoLocalDateTime() {
    return optional(Converter::intoLocalDateTime);
  }
  
  public Optional<ZonedDateTime> intoZonedDateTime() {
    return optional(Converter::intoZonedDateTime);
  }
  
  public Optional<ZonedDateTime> intoZonedDateTimeOrUse(ZoneId fallback) {
    return optional(c -> c.intoZonedDateTimeOrUse(fallback));
  }
}
