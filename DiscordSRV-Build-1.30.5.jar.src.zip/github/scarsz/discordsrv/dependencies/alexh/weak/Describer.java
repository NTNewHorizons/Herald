package github.scarsz.discordsrv.dependencies.alexh.weak;

interface Describer {
  String describe();
}
