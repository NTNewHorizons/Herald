package github.scarsz.discordsrv.dependencies.alexh.weak;

import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

class DescriptionDeferringAbsence extends AbstractAbsence<DynamicChild> {
  DescriptionDeferringAbsence(DescriptionDeferringAbsence parent, Object key) {
    super(parent, key);
  }
  
  DescriptionDeferringAbsence(IssueDescribingChild parent, Object key) {
    super(parent, key);
  }
  
  public Dynamic get(Object key) {
    return new DescriptionDeferringAbsence(this, key);
  }
  
  public Object asObject() {
    LinkedList<DynamicChild> chainFromDescriber = DynamicChildLogic.using(this).getAscendingChainAllWith(DescriptionDeferringAbsence.class::isInstance);
    throw new NoSuchElementException(((IssueDescribingChild)((DynamicChild)chainFromDescriber.getFirst()).parent())
        .describeIssue((List)chainFromDescriber.stream().map(child -> child.key().asObject()).collect(Collectors.toList())));
  }
}
