package github.scarsz.discordsrv.dependencies.alexh.weak;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Spliterators;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public interface Dynamic extends Weak<Dynamic> {
  public static final String ROOT_KEY = "root";
  
  static Dynamic from(Object val) {
    if (val == null)
      return DynamicNothing.INSTANCE; 
    if (val instanceof Dynamic)
      return (Dynamic)val; 
    if (val instanceof Map)
      return new DynamicMap((Map<?, ?>)val); 
    if (val instanceof List)
      return new DynamicList((List)val); 
    if (val instanceof Collection)
      return new DynamicCollection((Collection)val); 
    return new DynamicSomething(val);
  }
  
  default Dynamic get(String keyPath, String separator) {
    Dynamic result = this;
    for (String part : keyPath.split(Pattern.quote(separator)))
      result = result.get(part); 
    return result;
  }
  
  default Dynamic dget(String dotSeparatedPath) {
    return get(dotSeparatedPath, ".");
  }
  
  default Stream<Dynamic> allChildren() {
    return allChildrenDepthFirst();
  }
  
  default Stream<Dynamic> allChildrenDepthFirst() {
    return children().flatMap(child -> Stream.concat(Stream.of(child), child.allChildrenDepthFirst()));
  }
  
  default Stream<Dynamic> allChildrenBreadthFirst() {
    return StreamSupport.stream(Spliterators.spliteratorUnknownSize(new BreadthChildIterator(this), 16), false);
  }
  
  default <T> T as(Class<T> type) {
    try {
      return type.cast(asObject());
    } catch (ClassCastException ex) {
      throw new ClassCastException(String.format("'root' miscast: %s. Avoid by checking `if (aDynamic.is(%s.class)) ...` or using `aDynamic.maybe().as(%<s.class)`", new Object[] { ex
              .getMessage(), type.getSimpleName() }));
    } 
  }
  
  Dynamic get(Object paramObject);
  
  Stream<Dynamic> children();
  
  Weak<?> key();
}
