package github.scarsz.discordsrv.dependencies.alexh.weak;

import github.scarsz.discordsrv.dependencies.alexh.LiteJoiner;
import java.util.Collection;
import java.util.stream.Stream;

class DynamicCollection extends AbstractDynamic<Collection> implements Dynamic, Describer {
  static final String NO_KEY = "?";
  
  DynamicCollection(Collection inner) {
    super(inner);
  }
  
  protected Object keyLiteral() {
    return "root";
  }
  
  public Dynamic get(Object childKey) {
    if (this.inner.isEmpty())
      return new ParentAbsence.Empty<>(this, childKey); 
    return new ChildAbsence.Missing<>(this, childKey);
  }
  
  public Stream<Dynamic> children() {
    return this.inner.stream()
      .map(val -> (val == null) ? new ChildAbsence.Null(this, "?") : DynamicChild.from(this, "?", val));
  }
  
  public String describe() {
    String type = (this.inner instanceof java.util.Set) ? "Set" : "Collection";
    if (this.inner.isEmpty())
      return "Empty-" + type; 
    return type + "[size:" + this.inner.size() + "]";
  }
  
  public String toString() {
    return keyLiteral() + ":" + describe();
  }
  
  static class Child extends DynamicCollection implements DynamicChild {
    private final Dynamic parent;
    
    private final Object key;
    
    Child(Dynamic parent, Object key, Collection inner) {
      super(inner);
      this.parent = parent;
      this.key = key;
    }
    
    public Dynamic parent() {
      return this.parent;
    }
    
    public Object keyLiteral() {
      return this.key;
    }
    
    public String toString() {
      return LiteJoiner.on("->").join(DynamicChildLogic.using(this).getAscendingKeyChainWithRoot()) + ":" + 
        describe();
    }
  }
}
