package github.scarsz.discordsrv.dependencies.alexh.weak;

import github.scarsz.discordsrv.dependencies.alexh.LiteJoiner;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;
import java.util.stream.Stream;

class DynamicList extends AbstractDynamic<List> implements Dynamic, Describer {
  public DynamicList(List inner) {
    super(inner);
  }
  
  public Dynamic get(Object key) {
    if (this.inner.isEmpty())
      return new ParentAbsence.Empty<>(this, key); 
    Integer index = Optional.<Object>ofNullable(key).flatMap(k -> Converter.convert(k).maybe().intoInteger()).orElse(null);
    if (index == null)
      return new ChildAbsence.Missing<>(this, key); 
    if (index.intValue() < 0 || index.intValue() >= this.inner.size())
      return new ChildAbsence.Missing<>(this, index); 
    Object val = this.inner.get(index.intValue());
    return (val != null) ? DynamicChild.from(this, index, val) : new ChildAbsence.Null(this, index);
  }
  
  public Stream<Dynamic> children() {
    return IntStream.range(0, this.inner.size()).mapToObj(this::get);
  }
  
  public String describe() {
    String type = "List";
    switch (this.inner.size()) {
      case 0:
        return "Empty-List";
      case 1:
        return "List[0]";
      case 2:
        return "List[0, 1]";
    } 
    return String.format("%s[0..%d]", new Object[] { "List", Integer.valueOf(this.inner.size() - 1) });
  }
  
  protected Object keyLiteral() {
    return "root";
  }
  
  public String toString() {
    return keyLiteral() + ":" + describe();
  }
  
  static class Child extends DynamicList implements DynamicChild {
    private final Dynamic parent;
    
    private final Object key;
    
    Child(Dynamic parent, Object key, List inner) {
      super(inner);
      this.parent = parent;
      this.key = key;
    }
    
    public Dynamic parent() {
      return this.parent;
    }
    
    public Object keyLiteral() {
      return this.key;
    }
    
    public String toString() {
      return LiteJoiner.on("->").join(DynamicChildLogic.using(this).getAscendingKeyChainWithRoot()) + ":" + describe();
    }
  }
}
