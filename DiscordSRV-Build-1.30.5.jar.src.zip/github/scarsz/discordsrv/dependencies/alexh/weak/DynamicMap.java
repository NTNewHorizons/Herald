package github.scarsz.discordsrv.dependencies.alexh.weak;

import github.scarsz.discordsrv.dependencies.alexh.LiteJoiner;
import java.util.Map;
import java.util.stream.Stream;

class DynamicMap extends AbstractDynamic<Map<?, ?>> implements Dynamic, Describer {
  public DynamicMap(Map<?, ?> inner) {
    super(inner);
  }
  
  public Dynamic get(Object childKey) {
    if (this.inner.isEmpty())
      return new ParentAbsence.Empty<>(this, childKey); 
    if (!this.inner.containsKey(childKey)) {
      if (childKey instanceof String)
        for (Map.Entry<?, ?> entry : this.inner.entrySet()) {
          if (childKey.equals(entry.getKey().toString()))
            return (entry.getValue() != null) ? DynamicChild.from(this, childKey, entry.getValue()) : new ChildAbsence.Null(this, childKey); 
        }  
      String keyString = childKey.toString();
      if (this.inner.containsKey(keyString)) {
        Object object = this.inner.get(keyString);
        return (object != null) ? DynamicChild.from(this, keyString, object) : new ChildAbsence.Null(this, keyString);
      } 
      return new ChildAbsence.Missing<>(this, childKey);
    } 
    Object val = this.inner.get(childKey);
    return (val != null) ? DynamicChild.from(this, childKey, val) : new ChildAbsence.Null(this, childKey);
  }
  
  public Stream<Dynamic> children() {
    return this.inner.keySet().stream().map(this::get);
  }
  
  public String describe() {
    if (this.inner.isEmpty())
      return "Empty-Map"; 
    return "Map" + this.inner.keySet().toString();
  }
  
  public Object keyLiteral() {
    return "root";
  }
  
  public String toString() {
    return keyLiteral() + ":" + describe();
  }
  
  static class Child extends DynamicMap implements DynamicChild {
    private final Dynamic parent;
    
    private final Object key;
    
    Child(Dynamic parent, Object key, Map<?, ?> inner) {
      super(inner);
      this.parent = parent;
      this.key = key;
    }
    
    public Dynamic parent() {
      return this.parent;
    }
    
    public Object keyLiteral() {
      return this.key;
    }
    
    public String toString() {
      return LiteJoiner.on("->").join(DynamicChildLogic.using(this).getAscendingKeyChainWithRoot()) + ":" + describe();
    }
  }
}
