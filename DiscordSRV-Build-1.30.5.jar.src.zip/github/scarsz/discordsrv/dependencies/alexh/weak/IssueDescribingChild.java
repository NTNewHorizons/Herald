package github.scarsz.discordsrv.dependencies.alexh.weak;

import java.util.List;

interface IssueDescribingChild extends DynamicChild {
  String describeIssue(List<Object> paramList);
}
