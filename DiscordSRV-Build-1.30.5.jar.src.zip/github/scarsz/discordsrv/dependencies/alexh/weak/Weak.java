package github.scarsz.discordsrv.dependencies.alexh.weak;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface Weak<Self extends Weak<Self>> {
  boolean isPresent();
  
  Object asObject();
  
  default Optional<Object> asOptional() {
    return isPresent() ? Optional.<Object>of(asObject()) : Optional.<Object>empty();
  }
  
  default <T> T as(Class<T> type) {
    return type.cast(asObject());
  }
  
  default String asString() {
    return as(String.class);
  }
  
  default <T> List<T> asList() {
    return as((Class)List.class);
  }
  
  default <K, V> Map<K, V> asMap() {
    return as((Class)Map.class);
  }
  
  default boolean is(Class<?> type) {
    return (isPresent() && type.isInstance(asObject()));
  }
  
  default boolean isMap() {
    return is(Map.class);
  }
  
  default boolean isString() {
    return is(String.class);
  }
  
  default boolean isList() {
    return is(List.class);
  }
  
  default Converter convert() {
    return Converter.convert(asObject());
  }
  
  default OptionalWeak<Self> maybe() {
    return isPresent() ? OptionalWeak.<Self>of((Self)this) : OptionalWeak.<Self>empty();
  }
}
