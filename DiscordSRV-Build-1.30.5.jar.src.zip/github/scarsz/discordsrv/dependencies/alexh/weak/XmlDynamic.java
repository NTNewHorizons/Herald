package github.scarsz.discordsrv.dependencies.alexh.weak;

import github.scarsz.discordsrv.dependencies.alexh.Unchecker;
import java.io.Reader;
import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSSerializer;
import org.xml.sax.InputSource;

public class XmlDynamic extends AbstractDynamic<Node> implements Describer {
  private static final String FALLBACK_TO_STRING = "Xml[unable to serialize]";
  
  private static final String NONE_NAMESPACE = "none";
  
  private static final String NS_INDICATOR = "::";
  
  private static Stream<Node> streamChildNodes(Node node) {
    int children = node.getChildNodes().getLength();
    Node firstChild = node.getFirstChild();
    if (firstChild == null)
      return Stream.empty(); 
    return Stream.<Node>iterate(firstChild, prev -> (prev != null) ? prev.getNextSibling() : null)
      .limit(children)
      .filter(n -> (n != null));
  }
  
  private static Stream<Node> streamAttributes(Node node) {
    NamedNodeMap attributes = node.getAttributes();
    if (attributes == null)
      return Stream.empty(); 
    return IntStream.range(0, attributes.getLength()).mapToObj(attributes::item);
  }
  
  private static Node inputSourceToNode(InputSource xml) {
    XPathExpression all = (XPathExpression)Unchecker.uncheckedGet(() -> XPathFactory.newInstance().newXPath().compile("//*"));
    synchronized (XPathExpression.class) {
      return (Node)Unchecker.uncheckedGet(() -> (Node)all.evaluate(xml, XPathConstants.NODE));
    } 
  }
  
  public static Predicate<? super Dynamic> hasElementName(String elementName) {
    String[] nsKey = elementName.split("::");
    return element -> {
        if (!(element instanceof XmlDynamic))
          return false; 
        String simpleName = elementName;
        if (nsKey.length == 2) {
          String namespace = nsKey[0];
          String elNamespace = ((XmlDynamic)element).inner.getNamespaceURI();
          if ("none".equals(namespace)) {
            if (elNamespace != null)
              return false; 
          } else if (!namespace.equals(elNamespace)) {
            return false;
          } 
          simpleName = nsKey[1];
        } 
        String key = element.key().asString();
        if (key.endsWith("]"))
          key = key.substring(0, key.lastIndexOf("[")); 
        return key.equalsIgnoreCase(simpleName);
      };
  }
  
  public XmlDynamic(Node inner) {
    super(inner);
  }
  
  public XmlDynamic(InputSource xml) {
    this(inputSourceToNode(xml));
  }
  
  public XmlDynamic(Reader xml) {
    this(new InputSource(xml));
  }
  
  public XmlDynamic(String xml) {
    this(new StringReader(xml));
  }
  
  public boolean is(Class<?> type) {
    return String.class.equals(type);
  }
  
  public Dynamic get(Object keyObject) {
    Optional<? extends Dynamic> match;
    String keyToString = keyObject.toString();
    if (keyToString.contains("|"))
      return get(keyToString, "|"); 
    if (children().allMatch(o -> false)) {
      if (asString().isEmpty())
        return new ParentAbsence.Empty<>(this, keyObject); 
      return new ParentAbsence.Barren<>(this, keyObject);
    } 
    String key = keyToString.endsWith("[0]") ? keyToString.substring(0, keyToString.length() - 3) : keyToString;
    String[] nsKey = key.split("::");
    if (nsKey.length == 2)
      return getWithNamespace(nsKey[0], nsKey[1]); 
    if (key.isEmpty()) {
      match = Optional.empty();
    } else if (key.startsWith("@")) {
      match = attributes().filter(attr -> attr.key.equals(key)).findAny();
    } else if (key.endsWith("]")) {
      match = elements().filter(el -> el.key.equals(key)).findAny();
    } else {
      match = Stream.<Dynamic>concat(elements().filter(el -> el.key.equals(key)), attributes().filter(attr -> attr.key.equals("@" + key))).findFirst();
    } 
    return match.<Dynamic>map(Dynamic.class::cast).orElse(new ChildAbsence.Missing<>(this, keyObject));
  }
  
  protected Dynamic getWithNamespace(String namespace, String key) {
    Optional<? extends Dynamic> match;
    Predicate<Node> nodeInNamespace;
    if ("none".equals(namespace)) {
      nodeInNamespace = (node -> (node.getNamespaceURI() == null));
    } else {
      nodeInNamespace = (node -> namespace.equals(node.getNamespaceURI()));
    } 
    if (key.isEmpty()) {
      match = Optional.empty();
    } else if (key.startsWith("@")) {
      match = attributesWith(nodeInNamespace).filter(attr -> attr.key.equals(key)).findAny();
    } else if (key.endsWith("]")) {
      match = elementsWith(nodeInNamespace).filter(el -> el.key.equals(key)).findAny();
    } else {
      match = Stream.<Dynamic>concat(elementsWith(nodeInNamespace).filter(el -> el.key.equals(key)), attributesWith(nodeInNamespace).filter(attr -> attr.key.equals("@" + key))).findFirst();
    } 
    return match.<Dynamic>map(Dynamic.class::cast).orElse(new ChildAbsence.Missing<>(this, namespace + "::" + key));
  }
  
  protected Stream<Child> attributes() {
    return attributesWith(n -> true);
  }
  
  protected Stream<Child> attributesWith(Predicate<Node> predicate) {
    return Stream.empty();
  }
  
  protected Stream<Child> elements() {
    return elementsWith(n -> true);
  }
  
  protected Stream<Child> elementsWith(Predicate<Node> predicate) {
    return Stream.<Node>of(this.inner).filter(predicate).map(n -> childElement(n, 0));
  }
  
  public Stream<Dynamic> children() {
    synchronized (this.inner.getOwnerDocument()) {
      return Stream.concat((Stream)elements(), (Stream)attributes());
    } 
  }
  
  protected Object keyLiteral() {
    return "root";
  }
  
  public String describe() {
    if (isString() && asString().isEmpty())
      return "Empty-Xml"; 
    List<String> keys = (List<String>)Stream.<Child>concat(elements(), attributes()).map(child -> child.key).collect(Collectors.toList());
    Map<String, Integer> keyLastIndex = new HashMap<>();
    keys.forEach(key -> {
          if (key.endsWith("]")) {
            StringBuilder index = new StringBuilder();
            for (int i = key.length() - 2; i != -1; i--) {
              char c = key.charAt(i);
              if (c == '[')
                break; 
              index.append(c);
            } 
            if (index.length() != 0)
              keyLastIndex.put(key.substring(0, key.indexOf("[")), Integer.valueOf(index.toString())); 
          } 
        });
    keyLastIndex.forEach((multiKey, maxIndex) -> {
          keys.removeIf(());
          keys.add(multiKey + "[0.." + maxIndex + "]");
        });
    return keys.isEmpty() ? "Xml" : ("Xml" + keys.toString());
  }
  
  Child childElement(Node inner, int index) {
    return new Child(inner, this, (index == 0) ? inner.getLocalName() : (inner.getLocalName() + '[' + index + ']'));
  }
  
  public int hashCode() {
    String toString = fullXml();
    return "Xml[unable to serialize]".equals(toString) ? super.hashCode() : toString.hashCode();
  }
  
  public boolean equals(Object o) {
    if (this == o)
      return true; 
    if (o == null || getClass() != o.getClass())
      return false; 
    String otherAsString = ((XmlDynamic)o).fullXml();
    return (!"Xml[unable to serialize]".equals(otherAsString) && otherAsString.equals(fullXml()));
  }
  
  protected LSSerializer serializer() {
    LSSerializer serializer = ((DOMImplementationLS)this.inner.getOwnerDocument().getImplementation().getFeature("LS", "3.0")).createLSSerializer();
    serializer.getDomConfig().setParameter("xml-declaration", Boolean.valueOf(false));
    return serializer;
  }
  
  public String asObject() {
    synchronized (this.inner.getOwnerDocument()) {
      return serializer().writeToString(this.inner);
    } 
  }
  
  public String fullXml() {
    try {
      synchronized (this.inner.getOwnerDocument()) {
        return serializer().writeToString(this.inner);
      } 
    } catch (RuntimeException ex) {
      return "Xml[unable to serialize]";
    } 
  }
  
  public String toString() {
    return keyLiteral() + ":" + describe();
  }
  
  static class Child extends XmlDynamic implements DynamicChild {
    private final Dynamic parent;
    
    private final String key;
    
    Child(Node inner, Dynamic parent, String key) {
      super(inner);
      this.parent = parent;
      this.key = Objects.<String>requireNonNull(key);
    }
    
    public String asObject() {
      synchronized (this.inner.getOwnerDocument()) {
        return Optional.<Node>ofNullable(this.inner.getFirstChild())
          .map(Node::getNodeValue)
          .orElseGet(() -> (String)elements().map(XmlDynamic::fullXml).map(String::trim).reduce(()).orElse(""));
      } 
    }
    
    protected Stream<Child> attributesWith(Predicate<Node> predicate) {
      Map<String, Integer> keyLastIndex = new HashMap<>();
      return XmlDynamic.streamAttributes(this.inner)
        .filter(predicate)
        .map(attr -> {
            Integer index = Optional.ofNullable(keyLastIndex.get(attr.getLocalName())).map(()).orElse(Integer.valueOf(0));
            keyLastIndex.put(attr.getLocalName(), index);
            return childAttribute(attr, index.intValue());
          });
    }
    
    protected Stream<Child> elementsWith(Predicate<Node> predicate) {
      Map<String, Integer> keyLastIndex = new HashMap<>();
      return XmlDynamic.streamChildNodes(this.inner)
        .filter(node -> (node.getLocalName() != null))
        .filter(predicate)
        .map(node -> {
            Integer index = Optional.ofNullable(keyLastIndex.get(node.getLocalName())).map(()).orElse(Integer.valueOf(0));
            keyLastIndex.put(node.getLocalName(), index);
            return childElement(node, index.intValue());
          });
    }
    
    public Dynamic parent() {
      return this.parent;
    }
    
    public Object keyLiteral() {
      return this.key;
    }
    
    Child childAttribute(Node inner, int index) {
      String name = "@" + inner.getLocalName();
      return new Child(inner, this, (index == 0) ? name : (name + '[' + index + ']'));
    }
  }
}
