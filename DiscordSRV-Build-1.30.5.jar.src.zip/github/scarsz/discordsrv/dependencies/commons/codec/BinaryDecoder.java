package github.scarsz.discordsrv.dependencies.commons.codec;

public interface BinaryDecoder extends Decoder {
  byte[] decode(byte[] paramArrayOfbyte) throws DecoderException;
}
