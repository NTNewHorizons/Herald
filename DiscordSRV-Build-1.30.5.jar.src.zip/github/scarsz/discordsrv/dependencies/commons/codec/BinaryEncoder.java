package github.scarsz.discordsrv.dependencies.commons.codec;

public interface BinaryEncoder extends Encoder {
  byte[] encode(byte[] paramArrayOfbyte) throws EncoderException;
}
