package github.scarsz.discordsrv.dependencies.commons.codec;

public enum CodecPolicy {
  STRICT, LENIENT;
}
