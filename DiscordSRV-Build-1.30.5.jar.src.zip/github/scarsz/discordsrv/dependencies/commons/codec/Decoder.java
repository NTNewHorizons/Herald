package github.scarsz.discordsrv.dependencies.commons.codec;

public interface Decoder {
  Object decode(Object paramObject) throws DecoderException;
}
