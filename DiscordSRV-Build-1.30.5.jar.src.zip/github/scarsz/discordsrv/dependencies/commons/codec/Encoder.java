package github.scarsz.discordsrv.dependencies.commons.codec;

public interface Encoder {
  Object encode(Object paramObject) throws EncoderException;
}
