package github.scarsz.discordsrv.dependencies.commons.codec.binary;

import github.scarsz.discordsrv.dependencies.commons.codec.BinaryDecoder;
import github.scarsz.discordsrv.dependencies.commons.codec.BinaryEncoder;
import github.scarsz.discordsrv.dependencies.commons.codec.CodecPolicy;
import github.scarsz.discordsrv.dependencies.commons.codec.DecoderException;
import github.scarsz.discordsrv.dependencies.commons.codec.EncoderException;
import java.util.Arrays;
import java.util.Objects;

public abstract class BaseNCodec implements BinaryEncoder, BinaryDecoder {
  static final int EOF = -1;
  
  public static final int MIME_CHUNK_SIZE = 76;
  
  public static final int PEM_CHUNK_SIZE = 64;
  
  private static final int DEFAULT_BUFFER_RESIZE_FACTOR = 2;
  
  private static final int DEFAULT_BUFFER_SIZE = 8192;
  
  private static final int MAX_BUFFER_SIZE = 2147483639;
  
  protected static final int MASK_8BITS = 255;
  
  protected static final byte PAD_DEFAULT = 61;
  
  static class Context {
    int ibitWorkArea;
    
    long lbitWorkArea;
    
    byte[] buffer;
    
    int pos;
    
    int readPos;
    
    boolean eof;
    
    int currentLinePos;
    
    int modulus;
    
    public String toString() {
      return String.format("%s[buffer=%s, currentLinePos=%s, eof=%s, ibitWorkArea=%s, lbitWorkArea=%s, modulus=%s, pos=%s, readPos=%s]", new Object[] { getClass().getSimpleName(), Arrays.toString(this.buffer), 
            Integer.valueOf(this.currentLinePos), Boolean.valueOf(this.eof), Integer.valueOf(this.ibitWorkArea), Long.valueOf(this.lbitWorkArea), Integer.valueOf(this.modulus), Integer.valueOf(this.pos), Integer.valueOf(this.readPos) });
    }
  }
  
  protected static final CodecPolicy DECODING_POLICY_DEFAULT = CodecPolicy.LENIENT;
  
  static final byte[] CHUNK_SEPARATOR = new byte[] { 13, 10 };
  
  private static int compareUnsigned(int x, int y) {
    return Integer.compare(x + Integer.MIN_VALUE, y + Integer.MIN_VALUE);
  }
  
  private static int createPositiveCapacity(int minCapacity) {
    if (minCapacity < 0)
      throw new OutOfMemoryError("Unable to allocate array size: " + (minCapacity & 0xFFFFFFFFL)); 
    return (minCapacity > 2147483639) ? minCapacity : 2147483639;
  }
  
  public static byte[] getChunkSeparator() {
    return (byte[])CHUNK_SEPARATOR.clone();
  }
  
  protected static boolean isWhiteSpace(byte byteToCheck) {
    switch (byteToCheck) {
      case 9:
      case 10:
      case 13:
      case 32:
        return true;
    } 
    return false;
  }
  
  private static byte[] resizeBuffer(Context context, int minCapacity) {
    int oldCapacity = context.buffer.length;
    int newCapacity = oldCapacity * 2;
    if (compareUnsigned(newCapacity, minCapacity) < 0)
      newCapacity = minCapacity; 
    if (compareUnsigned(newCapacity, 2147483639) > 0)
      newCapacity = createPositiveCapacity(minCapacity); 
    byte[] b = new byte[newCapacity];
    System.arraycopy(context.buffer, 0, b, 0, context.buffer.length);
    context.buffer = b;
    return b;
  }
  
  @Deprecated
  protected final byte PAD = 61;
  
  protected final byte pad;
  
  private final int unencodedBlockSize;
  
  private final int encodedBlockSize;
  
  protected final int lineLength;
  
  private final int chunkSeparatorLength;
  
  private final CodecPolicy decodingPolicy;
  
  protected BaseNCodec(int unencodedBlockSize, int encodedBlockSize, int lineLength, int chunkSeparatorLength) {
    this(unencodedBlockSize, encodedBlockSize, lineLength, chunkSeparatorLength, (byte)61);
  }
  
  protected BaseNCodec(int unencodedBlockSize, int encodedBlockSize, int lineLength, int chunkSeparatorLength, byte pad) {
    this(unencodedBlockSize, encodedBlockSize, lineLength, chunkSeparatorLength, pad, DECODING_POLICY_DEFAULT);
  }
  
  protected BaseNCodec(int unencodedBlockSize, int encodedBlockSize, int lineLength, int chunkSeparatorLength, byte pad, CodecPolicy decodingPolicy) {
    this.unencodedBlockSize = unencodedBlockSize;
    this.encodedBlockSize = encodedBlockSize;
    boolean useChunking = (lineLength > 0 && chunkSeparatorLength > 0);
    this.lineLength = useChunking ? (lineLength / encodedBlockSize * encodedBlockSize) : 0;
    this.chunkSeparatorLength = chunkSeparatorLength;
    this.pad = pad;
    this.decodingPolicy = Objects.<CodecPolicy>requireNonNull(decodingPolicy, "codecPolicy");
  }
  
  int available(Context context) {
    return (context.buffer != null) ? (context.pos - context.readPos) : 0;
  }
  
  protected boolean containsAlphabetOrPad(byte[] arrayOctet) {
    if (arrayOctet == null)
      return false; 
    for (byte element : arrayOctet) {
      if (this.pad == element || isInAlphabet(element))
        return true; 
    } 
    return false;
  }
  
  public byte[] decode(byte[] pArray) {
    if (pArray == null || pArray.length == 0)
      return pArray; 
    Context context = new Context();
    decode(pArray, 0, pArray.length, context);
    decode(pArray, 0, -1, context);
    byte[] result = new byte[context.pos];
    readResults(result, 0, result.length, context);
    return result;
  }
  
  abstract void decode(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, Context paramContext);
  
  public Object decode(Object obj) throws DecoderException {
    if (obj instanceof byte[])
      return decode((byte[])obj); 
    if (obj instanceof String)
      return decode((String)obj); 
    throw new DecoderException("Parameter supplied to Base-N decode is not a byte[] or a String");
  }
  
  public byte[] decode(String pArray) {
    return decode(StringUtils.getBytesUtf8(pArray));
  }
  
  public byte[] encode(byte[] pArray) {
    if (pArray == null || pArray.length == 0)
      return pArray; 
    return encode(pArray, 0, pArray.length);
  }
  
  public byte[] encode(byte[] pArray, int offset, int length) {
    if (pArray == null || pArray.length == 0)
      return pArray; 
    Context context = new Context();
    encode(pArray, offset, length, context);
    encode(pArray, offset, -1, context);
    byte[] buf = new byte[context.pos - context.readPos];
    readResults(buf, 0, buf.length, context);
    return buf;
  }
  
  abstract void encode(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, Context paramContext);
  
  public Object encode(Object obj) throws EncoderException {
    if (!(obj instanceof byte[]))
      throw new EncoderException("Parameter supplied to Base-N encode is not a byte[]"); 
    return encode((byte[])obj);
  }
  
  public String encodeAsString(byte[] pArray) {
    return StringUtils.newStringUtf8(encode(pArray));
  }
  
  public String encodeToString(byte[] pArray) {
    return StringUtils.newStringUtf8(encode(pArray));
  }
  
  protected byte[] ensureBufferSize(int size, Context context) {
    if (context.buffer == null) {
      context.buffer = new byte[Math.max(size, getDefaultBufferSize())];
      context.pos = 0;
      context.readPos = 0;
    } else if (context.pos + size - context.buffer.length > 0) {
      return resizeBuffer(context, context.pos + size);
    } 
    return context.buffer;
  }
  
  public CodecPolicy getCodecPolicy() {
    return this.decodingPolicy;
  }
  
  protected int getDefaultBufferSize() {
    return 8192;
  }
  
  public long getEncodedLength(byte[] pArray) {
    long len = ((pArray.length + this.unencodedBlockSize - 1) / this.unencodedBlockSize) * this.encodedBlockSize;
    if (this.lineLength > 0)
      len += (len + this.lineLength - 1L) / this.lineLength * this.chunkSeparatorLength; 
    return len;
  }
  
  boolean hasData(Context context) {
    return (context.buffer != null);
  }
  
  protected abstract boolean isInAlphabet(byte paramByte);
  
  public boolean isInAlphabet(byte[] arrayOctet, boolean allowWSPad) {
    for (byte octet : arrayOctet) {
      if (!isInAlphabet(octet) && (!allowWSPad || (octet != this.pad && 
        !isWhiteSpace(octet))))
        return false; 
    } 
    return true;
  }
  
  public boolean isInAlphabet(String basen) {
    return isInAlphabet(StringUtils.getBytesUtf8(basen), true);
  }
  
  public boolean isStrictDecoding() {
    return (this.decodingPolicy == CodecPolicy.STRICT);
  }
  
  int readResults(byte[] b, int bPos, int bAvail, Context context) {
    if (context.buffer != null) {
      int len = Math.min(available(context), bAvail);
      System.arraycopy(context.buffer, context.readPos, b, bPos, len);
      context.readPos += len;
      if (context.readPos >= context.pos)
        context.buffer = null; 
      return len;
    } 
    return context.eof ? -1 : 0;
  }
}
