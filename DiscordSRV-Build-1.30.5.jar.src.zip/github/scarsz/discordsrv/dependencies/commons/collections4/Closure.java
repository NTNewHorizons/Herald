package github.scarsz.discordsrv.dependencies.commons.collections4;

public interface Closure<T> {
  void execute(T paramT);
}
