package github.scarsz.discordsrv.dependencies.commons.collections4;

public interface Factory<T> {
  T create();
}
