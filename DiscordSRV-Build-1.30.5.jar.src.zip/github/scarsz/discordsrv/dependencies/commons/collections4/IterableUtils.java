package github.scarsz.discordsrv.dependencies.commons.collections4;

import github.scarsz.discordsrv.dependencies.commons.collections4.functors.EqualPredicate;
import github.scarsz.discordsrv.dependencies.commons.collections4.iterators.LazyIteratorChain;
import github.scarsz.discordsrv.dependencies.commons.collections4.iterators.ReverseListIterator;
import github.scarsz.discordsrv.dependencies.commons.collections4.iterators.UniqueFilterIterator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class IterableUtils {
  static final FluentIterable EMPTY_ITERABLE = new FluentIterable() {
      public Iterator<Object> iterator() {
        return IteratorUtils.emptyIterator();
      }
    };
  
  public static <E> Iterable<E> emptyIterable() {
    return EMPTY_ITERABLE;
  }
  
  public static <E> Iterable<E> chainedIterable(Iterable<? extends E> a, Iterable<? extends E> b) {
    return chainedIterable((Iterable<? extends E>[])new Iterable[] { a, b });
  }
  
  public static <E> Iterable<E> chainedIterable(Iterable<? extends E> a, Iterable<? extends E> b, Iterable<? extends E> c) {
    return chainedIterable((Iterable<? extends E>[])new Iterable[] { a, b, c });
  }
  
  public static <E> Iterable<E> chainedIterable(Iterable<? extends E> a, Iterable<? extends E> b, Iterable<? extends E> c, Iterable<? extends E> d) {
    return chainedIterable((Iterable<? extends E>[])new Iterable[] { a, b, c, d });
  }
  
  public static <E> Iterable<E> chainedIterable(Iterable<? extends E>... iterables) {
    checkNotNull((Iterable<?>[])iterables);
    return new FluentIterable<E>() {
        public Iterator<E> iterator() {
          return (Iterator<E>)new LazyIteratorChain<E>() {
              protected Iterator<? extends E> nextIterator(int count) {
                if (count > iterables.length)
                  return null; 
                return iterables[count - 1].iterator();
              }
            };
        }
      };
  }
  
  public static <E> Iterable<E> collatedIterable(final Iterable<? extends E> a, final Iterable<? extends E> b) {
    checkNotNull((Iterable<?>[])new Iterable[] { a, b });
    return new FluentIterable<E>() {
        public Iterator<E> iterator() {
          return IteratorUtils.collatedIterator(null, a.iterator(), b.iterator());
        }
      };
  }
  
  public static <E> Iterable<E> collatedIterable(final Comparator<? super E> comparator, final Iterable<? extends E> a, final Iterable<? extends E> b) {
    checkNotNull((Iterable<?>[])new Iterable[] { a, b });
    return new FluentIterable<E>() {
        public Iterator<E> iterator() {
          return IteratorUtils.collatedIterator(comparator, a.iterator(), b.iterator());
        }
      };
  }
  
  public static <E> Iterable<E> filteredIterable(final Iterable<E> iterable, final Predicate<? super E> predicate) {
    checkNotNull(iterable);
    if (predicate == null)
      throw new NullPointerException("Predicate must not be null."); 
    return new FluentIterable<E>() {
        public Iterator<E> iterator() {
          return IteratorUtils.filteredIterator(IterableUtils.emptyIteratorIfNull(iterable), predicate);
        }
      };
  }
  
  public static <E> Iterable<E> boundedIterable(final Iterable<E> iterable, final long maxSize) {
    checkNotNull(iterable);
    if (maxSize < 0L)
      throw new IllegalArgumentException("MaxSize parameter must not be negative."); 
    return new FluentIterable<E>() {
        public Iterator<E> iterator() {
          return (Iterator)IteratorUtils.boundedIterator(iterable.iterator(), maxSize);
        }
      };
  }
  
  public static <E> Iterable<E> loopingIterable(final Iterable<E> iterable) {
    checkNotNull(iterable);
    return new FluentIterable<E>() {
        public Iterator<E> iterator() {
          return (Iterator<E>)new LazyIteratorChain<E>() {
              protected Iterator<? extends E> nextIterator(int count) {
                if (IterableUtils.isEmpty(iterable))
                  return null; 
                return iterable.iterator();
              }
            };
        }
      };
  }
  
  public static <E> Iterable<E> reversedIterable(final Iterable<E> iterable) {
    checkNotNull(iterable);
    return new FluentIterable<E>() {
        public Iterator<E> iterator() {
          List<E> list = (iterable instanceof List) ? (List<E>)iterable : IteratorUtils.<E>toList(iterable.iterator());
          return (Iterator<E>)new ReverseListIterator(list);
        }
      };
  }
  
  public static <E> Iterable<E> skippingIterable(final Iterable<E> iterable, final long elementsToSkip) {
    checkNotNull(iterable);
    if (elementsToSkip < 0L)
      throw new IllegalArgumentException("ElementsToSkip parameter must not be negative."); 
    return new FluentIterable<E>() {
        public Iterator<E> iterator() {
          return (Iterator)IteratorUtils.skippingIterator(iterable.iterator(), elementsToSkip);
        }
      };
  }
  
  public static <I, O> Iterable<O> transformedIterable(final Iterable<I> iterable, final Transformer<? super I, ? extends O> transformer) {
    checkNotNull(iterable);
    if (transformer == null)
      throw new NullPointerException("Transformer must not be null."); 
    return new FluentIterable<O>() {
        public Iterator<O> iterator() {
          return IteratorUtils.transformedIterator(iterable.iterator(), transformer);
        }
      };
  }
  
  public static <E> Iterable<E> uniqueIterable(final Iterable<E> iterable) {
    checkNotNull(iterable);
    return new FluentIterable<E>() {
        public Iterator<E> iterator() {
          return (Iterator<E>)new UniqueFilterIterator(iterable.iterator());
        }
      };
  }
  
  public static <E> Iterable<E> unmodifiableIterable(Iterable<E> iterable) {
    checkNotNull(iterable);
    if (iterable instanceof UnmodifiableIterable)
      return iterable; 
    return new UnmodifiableIterable<E>(iterable);
  }
  
  private static final class UnmodifiableIterable<E> extends FluentIterable<E> {
    private final Iterable<E> unmodifiable;
    
    public UnmodifiableIterable(Iterable<E> iterable) {
      this.unmodifiable = iterable;
    }
    
    public Iterator<E> iterator() {
      return IteratorUtils.unmodifiableIterator(this.unmodifiable.iterator());
    }
  }
  
  public static <E> Iterable<E> zippingIterable(final Iterable<? extends E> a, final Iterable<? extends E> b) {
    checkNotNull(a);
    checkNotNull(b);
    return new FluentIterable<E>() {
        public Iterator<E> iterator() {
          return (Iterator)IteratorUtils.zippingIterator(a.iterator(), b.iterator());
        }
      };
  }
  
  public static <E> Iterable<E> zippingIterable(final Iterable<? extends E> first, Iterable<? extends E>... others) {
    checkNotNull(first);
    checkNotNull((Iterable<?>[])others);
    return new FluentIterable<E>() {
        public Iterator<E> iterator() {
          Iterator[] arrayOfIterator = new Iterator[others.length + 1];
          arrayOfIterator[0] = first.iterator();
          for (int i = 0; i < others.length; i++)
            arrayOfIterator[i + 1] = others[i].iterator(); 
          return (Iterator)IteratorUtils.zippingIterator((Iterator<?>[])arrayOfIterator);
        }
      };
  }
  
  public static <E> Iterable<E> emptyIfNull(Iterable<E> iterable) {
    return (iterable == null) ? emptyIterable() : iterable;
  }
  
  public static <E> void forEach(Iterable<E> iterable, Closure<? super E> closure) {
    IteratorUtils.forEach(emptyIteratorIfNull(iterable), closure);
  }
  
  public static <E> E forEachButLast(Iterable<E> iterable, Closure<? super E> closure) {
    return IteratorUtils.forEachButLast(emptyIteratorIfNull(iterable), closure);
  }
  
  public static <E> E find(Iterable<E> iterable, Predicate<? super E> predicate) {
    return IteratorUtils.find(emptyIteratorIfNull(iterable), predicate);
  }
  
  public static <E> int indexOf(Iterable<E> iterable, Predicate<? super E> predicate) {
    return IteratorUtils.indexOf(emptyIteratorIfNull(iterable), predicate);
  }
  
  public static <E> boolean matchesAll(Iterable<E> iterable, Predicate<? super E> predicate) {
    return IteratorUtils.matchesAll(emptyIteratorIfNull(iterable), predicate);
  }
  
  public static <E> boolean matchesAny(Iterable<E> iterable, Predicate<? super E> predicate) {
    return IteratorUtils.matchesAny(emptyIteratorIfNull(iterable), predicate);
  }
  
  public static <E> long countMatches(Iterable<E> input, Predicate<? super E> predicate) {
    if (predicate == null)
      throw new NullPointerException("Predicate must not be null."); 
    return size(filteredIterable(emptyIfNull(input), predicate));
  }
  
  public static boolean isEmpty(Iterable<?> iterable) {
    if (iterable instanceof Collection)
      return ((Collection)iterable).isEmpty(); 
    return IteratorUtils.isEmpty(emptyIteratorIfNull(iterable));
  }
  
  public static <E> boolean contains(Iterable<E> iterable, Object object) {
    if (iterable instanceof Collection)
      return ((Collection)iterable).contains(object); 
    return IteratorUtils.contains(emptyIteratorIfNull(iterable), object);
  }
  
  public static <E> boolean contains(Iterable<? extends E> iterable, E object, Equator<? super E> equator) {
    if (equator == null)
      throw new NullPointerException("Equator must not be null."); 
    return matchesAny(iterable, EqualPredicate.equalPredicate(object, equator));
  }
  
  public static <E, T extends E> int frequency(Iterable<E> iterable, T obj) {
    if (iterable instanceof Set)
      return ((Set)iterable).contains(obj) ? 1 : 0; 
    if (iterable instanceof Bag)
      return ((Bag)iterable).getCount(obj); 
    return size(filteredIterable(emptyIfNull(iterable), EqualPredicate.equalPredicate(obj)));
  }
  
  public static <T> T get(Iterable<T> iterable, int index) {
    CollectionUtils.checkIndexBounds(index);
    if (iterable instanceof List)
      return ((List<T>)iterable).get(index); 
    return IteratorUtils.get(emptyIteratorIfNull(iterable), index);
  }
  
  public static int size(Iterable<?> iterable) {
    if (iterable instanceof Collection)
      return ((Collection)iterable).size(); 
    return IteratorUtils.size(emptyIteratorIfNull(iterable));
  }
  
  public static <O> List<List<O>> partition(Iterable<? extends O> iterable, Predicate<? super O> predicate) {
    if (predicate == null)
      throw new NullPointerException("Predicate must not be null."); 
    Factory<List<O>> factory = FactoryUtils.instantiateFactory((Class)ArrayList.class);
    Predicate[] arrayOfPredicate = { predicate };
    return partition(iterable, factory, (Predicate<? super O>[])arrayOfPredicate);
  }
  
  public static <O> List<List<O>> partition(Iterable<? extends O> iterable, Predicate<? super O>... predicates) {
    Factory<List<O>> factory = FactoryUtils.instantiateFactory((Class)ArrayList.class);
    return partition(iterable, factory, predicates);
  }
  
  public static <O, R extends Collection<O>> List<R> partition(Iterable<? extends O> iterable, Factory<R> partitionFactory, Predicate<? super O>... predicates) {
    if (iterable == null) {
      Iterable<O> empty = emptyIterable();
      return partition(empty, partitionFactory, predicates);
    } 
    if (predicates == null)
      throw new NullPointerException("Predicates must not be null."); 
    for (Predicate<?> p : predicates) {
      if (p == null)
        throw new NullPointerException("Predicate must not be null."); 
    } 
    if (predicates.length < 1) {
      Collection<O> collection = (Collection)partitionFactory.create();
      CollectionUtils.addAll(collection, iterable);
      return Collections.singletonList((R)collection);
    } 
    int numberOfPredicates = predicates.length;
    int numberOfPartitions = numberOfPredicates + 1;
    List<R> partitions = new ArrayList<R>(numberOfPartitions);
    for (int i = 0; i < numberOfPartitions; i++)
      partitions.add(partitionFactory.create()); 
    for (O element : iterable) {
      boolean elementAssigned = false;
      for (int j = 0; j < numberOfPredicates; j++) {
        if (predicates[j].evaluate(element)) {
          ((Collection<O>)partitions.get(j)).add(element);
          elementAssigned = true;
          break;
        } 
      } 
      if (!elementAssigned)
        ((Collection<O>)partitions.get(numberOfPredicates)).add(element); 
    } 
    return partitions;
  }
  
  public static <E> List<E> toList(Iterable<E> iterable) {
    return IteratorUtils.toList(emptyIteratorIfNull(iterable));
  }
  
  public static <E> String toString(Iterable<E> iterable) {
    return IteratorUtils.toString(emptyIteratorIfNull(iterable));
  }
  
  public static <E> String toString(Iterable<E> iterable, Transformer<? super E, String> transformer) {
    if (transformer == null)
      throw new NullPointerException("Transformer must not be null."); 
    return IteratorUtils.toString(emptyIteratorIfNull(iterable), transformer);
  }
  
  public static <E> String toString(Iterable<E> iterable, Transformer<? super E, String> transformer, String delimiter, String prefix, String suffix) {
    return IteratorUtils.toString(emptyIteratorIfNull(iterable), transformer, delimiter, prefix, suffix);
  }
  
  static void checkNotNull(Iterable<?> iterable) {
    if (iterable == null)
      throw new NullPointerException("Iterable must not be null."); 
  }
  
  static void checkNotNull(Iterable<?>... iterables) {
    if (iterables == null)
      throw new NullPointerException("Iterables must not be null."); 
    for (Iterable<?> iterable : iterables)
      checkNotNull(iterable); 
  }
  
  private static <E> Iterator<E> emptyIteratorIfNull(Iterable<E> iterable) {
    return (iterable != null) ? iterable.iterator() : IteratorUtils.<E>emptyIterator();
  }
}
