package github.scarsz.discordsrv.dependencies.commons.collections4;

public interface KeyValue<K, V> {
  K getKey();
  
  V getValue();
}
