package github.scarsz.discordsrv.dependencies.commons.collections4;

public interface OrderedMapIterator<K, V> extends MapIterator<K, V>, OrderedIterator<K> {
  boolean hasPrevious();
  
  K previous();
}
