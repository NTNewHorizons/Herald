package github.scarsz.discordsrv.dependencies.commons.collections4;

public interface Predicate<T> {
  boolean evaluate(T paramT);
}
