package github.scarsz.discordsrv.dependencies.commons.collections4;

public interface Transformer<I, O> {
  O transform(I paramI);
}
