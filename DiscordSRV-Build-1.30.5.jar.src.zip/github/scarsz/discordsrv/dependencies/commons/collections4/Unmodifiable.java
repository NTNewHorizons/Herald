package github.scarsz.discordsrv.dependencies.commons.collections4;

public interface Unmodifiable {}
