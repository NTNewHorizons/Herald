package github.scarsz.discordsrv.dependencies.commons.collections4.functors;

import github.scarsz.discordsrv.dependencies.commons.collections4.Transformer;

public class CloneTransformer<T> implements Transformer<T, T> {
  public static final Transformer INSTANCE = new CloneTransformer();
  
  public static <T> Transformer<T, T> cloneTransformer() {
    return INSTANCE;
  }
  
  public T transform(T input) {
    if (input == null)
      return null; 
    return (T)PrototypeFactory.<T>prototypeFactory(input).create();
  }
}
