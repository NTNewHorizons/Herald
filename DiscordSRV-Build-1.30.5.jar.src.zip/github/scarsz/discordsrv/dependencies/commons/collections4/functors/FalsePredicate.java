package github.scarsz.discordsrv.dependencies.commons.collections4.functors;

import github.scarsz.discordsrv.dependencies.commons.collections4.Predicate;
import java.io.Serializable;

public final class FalsePredicate<T> implements Predicate<T>, Serializable {
  private static final long serialVersionUID = 7533784454832764388L;
  
  public static final Predicate INSTANCE = new FalsePredicate();
  
  public static <T> Predicate<T> falsePredicate() {
    return INSTANCE;
  }
  
  public boolean evaluate(T object) {
    return false;
  }
  
  private Object readResolve() {
    return INSTANCE;
  }
}
