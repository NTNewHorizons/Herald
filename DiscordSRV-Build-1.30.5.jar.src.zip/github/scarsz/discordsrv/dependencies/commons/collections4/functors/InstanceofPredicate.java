package github.scarsz.discordsrv.dependencies.commons.collections4.functors;

import github.scarsz.discordsrv.dependencies.commons.collections4.Predicate;
import java.io.Serializable;

public final class InstanceofPredicate implements Predicate<Object>, Serializable {
  private static final long serialVersionUID = -6682656911025165584L;
  
  private final Class<?> iType;
  
  public static Predicate<Object> instanceOfPredicate(Class<?> type) {
    if (type == null)
      throw new NullPointerException("The type to check instanceof must not be null"); 
    return new InstanceofPredicate(type);
  }
  
  public InstanceofPredicate(Class<?> type) {
    this.iType = type;
  }
  
  public boolean evaluate(Object object) {
    return this.iType.isInstance(object);
  }
  
  public Class<?> getType() {
    return this.iType;
  }
}
