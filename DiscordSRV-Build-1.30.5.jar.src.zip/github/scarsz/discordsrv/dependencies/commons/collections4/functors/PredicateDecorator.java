package github.scarsz.discordsrv.dependencies.commons.collections4.functors;

import github.scarsz.discordsrv.dependencies.commons.collections4.Predicate;

public interface PredicateDecorator<T> extends Predicate<T> {
  Predicate<? super T>[] getPredicates();
}
