package github.scarsz.discordsrv.dependencies.commons.collections4.functors;

import github.scarsz.discordsrv.dependencies.commons.collections4.Predicate;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public final class UniquePredicate<T> implements Predicate<T>, Serializable {
  private static final long serialVersionUID = -3319417438027438040L;
  
  private final Set<T> iSet = new HashSet<T>();
  
  public static <T> Predicate<T> uniquePredicate() {
    return new UniquePredicate<T>();
  }
  
  public boolean evaluate(T object) {
    return this.iSet.add(object);
  }
}
