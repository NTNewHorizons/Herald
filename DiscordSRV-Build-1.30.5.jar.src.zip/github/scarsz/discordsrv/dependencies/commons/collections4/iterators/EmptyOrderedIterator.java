package github.scarsz.discordsrv.dependencies.commons.collections4.iterators;

import github.scarsz.discordsrv.dependencies.commons.collections4.OrderedIterator;
import github.scarsz.discordsrv.dependencies.commons.collections4.ResettableIterator;

public class EmptyOrderedIterator<E> extends AbstractEmptyIterator<E> implements OrderedIterator<E>, ResettableIterator<E> {
  public static final OrderedIterator INSTANCE = new EmptyOrderedIterator();
  
  public static <E> OrderedIterator<E> emptyOrderedIterator() {
    return INSTANCE;
  }
}
