package github.scarsz.discordsrv.dependencies.commons.collections4.iterators;

import github.scarsz.discordsrv.dependencies.commons.collections4.FluentIterable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

public class ZippingIterator<E> implements Iterator<E> {
  private final Iterator<Iterator<? extends E>> iterators;
  
  private Iterator<? extends E> nextIterator = null;
  
  private Iterator<? extends E> lastReturned = null;
  
  public ZippingIterator(Iterator<? extends E> a, Iterator<? extends E> b) {
    this((Iterator<? extends E>[])new Iterator[] { a, b });
  }
  
  public ZippingIterator(Iterator<? extends E> a, Iterator<? extends E> b, Iterator<? extends E> c) {
    this((Iterator<? extends E>[])new Iterator[] { a, b, c });
  }
  
  public ZippingIterator(Iterator<? extends E>... iterators) {
    List<Iterator<? extends E>> list = new ArrayList<Iterator<? extends E>>();
    for (Iterator<? extends E> iterator : iterators) {
      if (iterator == null)
        throw new NullPointerException("Iterator must not be null."); 
      list.add(iterator);
    } 
    this.iterators = FluentIterable.of(list).loop().iterator();
  }
  
  public boolean hasNext() {
    if (this.nextIterator != null)
      return true; 
    while (this.iterators.hasNext()) {
      Iterator<? extends E> childIterator = this.iterators.next();
      if (childIterator.hasNext()) {
        this.nextIterator = childIterator;
        return true;
      } 
      this.iterators.remove();
    } 
    return false;
  }
  
  public E next() throws NoSuchElementException {
    if (!hasNext())
      throw new NoSuchElementException(); 
    E val = this.nextIterator.next();
    this.lastReturned = this.nextIterator;
    this.nextIterator = null;
    return val;
  }
  
  public void remove() {
    if (this.lastReturned == null)
      throw new IllegalStateException("No value can be removed at present"); 
    this.lastReturned.remove();
    this.lastReturned = null;
  }
}
