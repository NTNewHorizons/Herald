package github.scarsz.discordsrv.dependencies.commons.collections4.map;

import github.scarsz.discordsrv.dependencies.commons.collections4.IterableMap;
import github.scarsz.discordsrv.dependencies.commons.collections4.MapIterator;

public abstract class AbstractIterableMap<K, V> implements IterableMap<K, V> {
  public MapIterator<K, V> mapIterator() {
    return new EntrySetToMapIteratorAdapter<K, V>(entrySet());
  }
}
