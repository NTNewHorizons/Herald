package github.scarsz.discordsrv.dependencies.commons.collections4.multiset;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;

public class HashMultiSet<E> extends AbstractMapMultiSet<E> implements Serializable {
  private static final long serialVersionUID = 20150610L;
  
  public HashMultiSet() {
    super(new HashMap<E, AbstractMapMultiSet.MutableInteger>());
  }
  
  public HashMultiSet(Collection<? extends E> coll) {
    this();
    addAll(coll);
  }
  
  private void writeObject(ObjectOutputStream out) throws IOException {
    out.defaultWriteObject();
    doWriteObject(out);
  }
  
  private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
    in.defaultReadObject();
    setMap(new HashMap<E, AbstractMapMultiSet.MutableInteger>());
    doReadObject(in);
  }
}
