package github.scarsz.discordsrv.dependencies.commons.collections4.set;

import github.scarsz.discordsrv.dependencies.commons.collections4.Predicate;
import github.scarsz.discordsrv.dependencies.commons.collections4.collection.PredicatedCollection;
import java.util.Collection;
import java.util.Set;

public class PredicatedSet<E> extends PredicatedCollection<E> implements Set<E> {
  private static final long serialVersionUID = -684521469108685117L;
  
  public static <E> PredicatedSet<E> predicatedSet(Set<E> set, Predicate<? super E> predicate) {
    return new PredicatedSet<E>(set, predicate);
  }
  
  protected PredicatedSet(Set<E> set, Predicate<? super E> predicate) {
    super(set, predicate);
  }
  
  protected Set<E> decorated() {
    return (Set<E>)super.decorated();
  }
  
  public boolean equals(Object object) {
    return (object == this || decorated().equals(object));
  }
  
  public int hashCode() {
    return decorated().hashCode();
  }
}
