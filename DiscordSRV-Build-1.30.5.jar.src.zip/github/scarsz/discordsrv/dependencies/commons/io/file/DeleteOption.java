package github.scarsz.discordsrv.dependencies.commons.io.file;

public interface DeleteOption {}
