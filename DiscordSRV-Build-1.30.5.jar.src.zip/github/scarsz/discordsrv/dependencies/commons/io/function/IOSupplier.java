package github.scarsz.discordsrv.dependencies.commons.io.function;

import java.io.IOException;

@FunctionalInterface
public interface IOSupplier<T> {
  T get() throws IOException;
}
